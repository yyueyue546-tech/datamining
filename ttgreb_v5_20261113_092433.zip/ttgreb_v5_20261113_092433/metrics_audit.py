"""Exact sufficient-statistic audit; never infer pooled F1 by averaging F1."""
import json
from pathlib import Path
import statistics


def confusion_from_record(row):
    n0, n1 = row['support']
    tn, tp = [round(n * r) for n, r in zip((n0, n1), row['recall'])]
    c = [[tn, n0 - tn], [n1 - tp, tp]]
    expected = scores(c)
    for key in ('precision', 'recall', 'f1'):
        if any(abs(a - b) > 1e-10 for a, b in zip(expected[key], row[key])):
            raise ValueError(f'Confusion reconstruction failed: {key}')
    if abs(expected['macro'] - row['metric']) > 1e-10:
        raise ValueError('Macro F1 reconstruction failed')
    if abs((c[0][1] + c[1][1]) / (n0 + n1) - row['predicted_positive_fraction']) > 1e-7:
        raise ValueError('Prediction fraction reconstruction failed')
    return c


def scores(c):
    tn, fp, fn, tp = c[0][0], c[0][1], c[1][0], c[1][1]
    div = lambda a, b: a / b if b else 0.
    p = [div(tn, tn + fn), div(tp, tp + fp)]
    r = [div(tn, tn + fp), div(tp, tp + fn)]
    f = [div(2 * tn, 2 * tn + fp + fn), div(2 * tp, 2 * tp + fp + fn)]
    # Match sklearn's default labels=union(y_true,y_pred), including one-class slices.
    present = [i for i in range(2) if sum(c[i]) + sum(row[i] for row in c) > 0]
    return dict(precision=p, recall=r, f1=f, macro=statistics.mean(f[i] for i in present),
                illicit_f1=f[1], illicit_recall=r[1])


def add_confusions(cs):
    return [[sum(c[i][j] for c in cs) for j in range(2)] for i in range(2)]


def aggregations(cs):
    # GTrans triggers at i % 4 == 0 or last: [0], [1..4], ..., [29..32].
    groups, current = [], []
    for i, c in enumerate(cs):
        current.append(c)
        if i % 4 == 0 or i == len(cs) - 1:
            groups.append(add_confusions(current)); current = []
    per_graph = [scores(c) for c in cs]
    grouped = [scores(c)['macro'] for c in groups]
    pooled = scores(add_confusions(cs))
    return dict(time_mean=statistics.mean(s['macro'] for s in per_graph),
                gtrans9_mean=statistics.mean(grouped),
                gtrans9_rounded_mean=statistics.mean(float(f'{s:.2f}') for s in grouped),
                pooled_macro=pooled['macro'], pooled_illicit_f1=pooled['illicit_f1'],
                pooled_illicit_recall=pooled['illicit_recall'],
                time_illicit_f1=statistics.mean(s['illicit_f1'] for s in per_graph),
                time_illicit_recall=statistics.mean(s['illicit_recall'] for s in per_graph),
                group_count=len(groups), grouped_macro=grouped)


def historical_audit(project, output):
    root = project / 'experiments/elliptic_twitch_v4/artifacts/elliptic'
    if not root.exists():
        archived=output/'metric_audit.json'
        if archived.exists():return json.loads(archived.read_text(encoding='utf8'))['records']
        return []
    rows, details = [], []
    for summary in sorted(root.glob('*/test/*/seed*/summary.json')):
        meta = json.loads(summary.read_text(encoding='utf8'))
        graphs = [json.loads((summary.parent / f'graph{i}.json').read_text(encoding='utf8')) for i in range(33)]
        if [g['time_step'] for g in graphs] != list(range(16, 49)):
            raise ValueError('Unexpected time order')
        if len({g['checkpoint_sha256'] for g in graphs}) != 1:
            raise ValueError('Mismatched checkpoints')
        for method in ('baseline', 'zero', 'adapted'):
            cs = [confusion_from_record(g[method]) for g in graphs]
            result = aggregations(cs)
            if abs(result['time_mean'] - meta[method]) > 1e-10:
                raise ValueError('Historical summary does not match exact confusions')
            rows.append(dict(model=meta['model'], role=meta['role'], seed=meta['seed'], method=method,
                             checkpoint_sha256=meta['checkpoint_sha256'], **result))
            details.append(dict(source=str(summary.relative_to(project)), method=method, confusion=cs))
    output.mkdir(parents=True, exist_ok=True)
    (output / 'metric_audit.json').write_text(json.dumps(dict(records=rows, confusions=details,
        reconstructed_confusions=sum(len(v['confusion']) for v in details),
        exact_precision_recall_f1_verified=True, predictions_unchanged=True), indent=2), encoding='utf8')
    return rows
