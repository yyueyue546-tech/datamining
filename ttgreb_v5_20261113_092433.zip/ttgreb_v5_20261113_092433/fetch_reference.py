"""Fetch a small, auditable snapshot of the cited GTrans backbone implementation."""
from pathlib import Path
import urllib.request
import hashlib
import json
import datetime

out=Path(__file__).resolve().parent/'reports/reference_sources'
out.mkdir(parents=True,exist_ok=True)
files=['gtransform_feat.py','gtransform_adj.py','models/base_model.py','models/gcn.py','models/sage.py']
rows=[]
for name in files:
    url='https://raw.githubusercontent.com/ChandlerBang/GTrans/main/'+name
    try:
        data=urllib.request.urlopen(url,timeout=20).read()
        path=out/name.replace('/','_')
        if path.exists() and path.read_bytes()!=data:raise RuntimeError('Source snapshot differs')
        path.write_bytes(data)
        rows.append(dict(url=url,file=path.name,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
        print(name,len(data),flush=True)
    except Exception as exc:
        rows.append(dict(url=url,error=repr(exc)));print(name,repr(exc),flush=True)
metadata=out/('sources_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.json')
metadata.write_text(json.dumps(rows,indent=2),encoding='utf8')
if any('error' in row for row in rows):raise SystemExit(1)
