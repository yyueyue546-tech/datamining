import unittest
import importlib.util
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import run_study as s
import torch
from torch_geometric.data import Data
from ttgreb.adapter import adapt_reweight
from ttgreb.models import build_model
from metrics_audit import aggregations, confusion_from_record, scores
from reference_aligned import ReferenceMeanConv, reference_update
from copy import deepcopy
from torch.nn import functional as F


class SupplementTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(4)
        self.g=Data(x=torch.randn(8,3),edge_index=torch.tensor([[0,1,2,3,4,5,6,7],[1,2,3,4,5,6,7,0]]))
        self.m=build_model('gcn',3,2,dict(hidden_channels=4,num_layers=2,dropout=0.,batch_norm=True)).eval()
        self.opts=dict(steps=2,lr=.001,hidden_dim=4,init_probability=.7,seed=19)

    def test_full_matches_preserved_core(self):
        old=s.PROJECT/'src/ttgreb/adapter.py'
        if not old.exists():self.skipTest('Historical source only present in development workspace')
        spec=importlib.util.spec_from_file_location('ttgreb.preserved_core',old)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        reference,_=module.adapt_reweight(self.m,self.g,**self.opts)
        actual,_=adapt_reweight(self.m,self.g,**self.opts)
        self.assertTrue(torch.equal(reference.x,actual.x))
        self.assertTrue(torch.equal(reference.edge_weight,actual.edge_weight))

    def test_ablations_freeze_excluded_module_and_backbone(self):
        frozen={k:v.clone() for k,v in self.m.state_dict().items()}
        for mode in ('features','edges'):
            result,info=adapt_reweight(self.m,self.g,mode=mode,**self.opts)
            self.assertEqual(info['updated_branches'],2)
            if mode=='edges':self.assertTrue(torch.equal(result.x,self.g.x))
            else:self.assertTrue(torch.equal(result.edge_weight,torch.ones(self.g.num_edges)))
        self.assertTrue(all(torch.equal(frozen[k],v) for k,v in self.m.state_dict().items()))

    def test_labels_do_not_affect_adaptation(self):
        a,_=adapt_reweight(self.m,self.g,**self.opts)
        g=self.g.clone();g.y=torch.arange(8)%2;g.mask=torch.zeros(8,dtype=torch.bool)
        b,_=adapt_reweight(self.m,g,**self.opts)
        self.assertTrue(torch.equal(a.x,b.x));self.assertTrue(torch.equal(a.edge_weight,b.edge_weight))

    def test_sufficient_statistics_and_time_grouping(self):
        c=[[80,10],[6,4]];r=scores(c)
        row=dict(support=[90,10],precision=r['precision'],recall=r['recall'],f1=r['f1'],
                 metric=r['macro'],predicted_positive_fraction=.14)
        self.assertEqual(confusion_from_record(row),c)
        report=aggregations([c]*33)
        self.assertEqual(report['group_count'],9)
        self.assertAlmostEqual(report['pooled_macro'],r['macro'])
        self.assertAlmostEqual(report['time_mean'],r['macro'])

    def test_reference_bias_is_averaged_with_neighbors(self):
        conv=ReferenceMeanConv(2,1)
        with torch.no_grad():
            conv.lin_l.weight.copy_(torch.tensor([[2.,3.]]));conv.lin_l.bias.fill_(7.)
            conv.lin_r.weight.zero_()
        x=torch.tensor([[1.,2.],[3.,4.],[5.,6.]])
        edges=torch.tensor([[0,1],[1,1]])
        result=conv(x,edges).reshape(-1)
        # Node 1 has two incoming nodes; nodes 0 and 2 have none, so no bias there.
        self.assertTrue(torch.equal(result,torch.tensor([0.,20.,0.])))

    def test_reference_averages_losses_before_single_optimizer_step(self):
        class Tiny(torch.nn.Module):
            def __init__(self):super().__init__();self.linear=torch.nn.Linear(2,2,bias=False)
            def forward(self,x,edge):return self.linear(x)
        model=Tiny();control=deepcopy(model)
        gs=[Data(x=torch.tensor([[1.,0.],[0.,2.]]),y=torch.tensor([0,1]),edge_index=torch.empty(2,0,dtype=torch.long)),
            Data(x=torch.tensor([[2.,1.]]),y=torch.tensor([1]),edge_index=torch.empty(2,0,dtype=torch.long))]
        optimizer=torch.optim.AdamW(model.parameters(),lr=.01)
        other=torch.optim.AdamW(control.parameters(),lr=.01)
        reference_update(model,gs,torch.tensor([0,1]),optimizer,'cross_entropy')
        other.zero_grad();loss=sum(F.cross_entropy(control(g.x,g.edge_index),g.y) for g in gs)/2
        loss.backward();other.step()
        self.assertTrue(torch.equal(model.linear.weight,control.linear.weight))
        self.assertEqual(int(optimizer.state[model.linear.weight]['step']),1)

    def test_effective_training_schedule_is_part_of_reuse_identity(self):
        config=dict(model={},training=dict(max_epochs=200),preprocessing={})
        explicit=deepcopy(config);explicit['training'].update(minimum_epochs=50,patience=50)
        self.assertEqual(s.training_key('elliptic','gcn',config,0,'time_mean'),s.training_key('elliptic','gcn',explicit,0,'time_mean'))
        full=deepcopy(config);full['training'].update(minimum_epochs=200,patience=500)
        self.assertNotEqual(s.training_key('elliptic','gcn',config,0,'time_mean'),s.training_key('elliptic','gcn',full,0,'time_mean'))


if __name__=='__main__':unittest.main()
