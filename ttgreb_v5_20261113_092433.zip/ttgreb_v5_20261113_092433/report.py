"""Regenerate only this release's human-readable and machine-readable reports."""
from datetime import datetime
import csv
import json
import statistics
import math
import sys
from pathlib import Path
import run_study as s
from metrics_audit import confusion_from_record, aggregations

PAPER={('cora','gcn'):(87.49,96.12),('cora','graphsage'):(98.48,99.66),
 ('amazon_photo','gcn'):(88.60,89.11),('amazon_photo','graphsage'):(84.03,88.49),
 ('elliptic','gcn'):(51.09,57.20),('elliptic','graphsage'):(57.34,66.97),
 ('twitch','gcn'):(59.80,60.85),('twitch','graphsage'):(62.08,62.43)}


def avg(rows,key):return statistics.mean(r[key] for r in rows)
def fmt(values):
    if not values:return '—'
    return f'{statistics.mean(values)*100:.4f} ± {statistics.stdev(values)*100 if len(values)>1 else 0:.4f}'


def write_csv(path,rows):
    if not rows:return
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def main():
    out=s.ROOT/'reports';out.mkdir(exist_ok=True)
    lines=['# TT-GREB 四数据集补充实验与可运行交付',f'\n生成时间：{datetime.now().astimezone().isoformat()}。',
      '\n历史实验保留。当前指标：Cora/Amazon 为环境平均准确率，Elliptic 为 33 时间片等权宏 F1，Twitch 为 5 域平均 AUC。数值以百分数表示，差值单位为百分点（pp）。图提示尚未加入。',
      '\n## 代码与运行入口',
      '\n本文件所在工程 `release_v5` 可单独复制为 GitHub 分支中的项目根目录，无需三个同学的源码目录。',
      '\n```text\nrelease_v5/\n  run_study.py          # 分阶段训练、验证选参、配对测试和消融\n  reference_aligned.py  # 引用 GTrans 设置的独立基线对照\n  metrics_audit.py      # 同一预测的 Elliptic 汇总口径对照\n  report.py            # 本报告、CSV 和结果核验\n  src/ttgreb/          # 数据、骨干、乘法适配器、原公式损失\n  configs/starting/    # 原验证锁定起点\n  configs/locked/      # 本轮最终配置\n  configs/reference/   # 引用设置的对照配置\n  tests/               # 标签隔离、冻结和消融行为测试\n  reports/             # 可上传的表格、证据和审计\n  artifacts/           # 本地完整日志、预测、checkpoint，默认不上传\n```',
      '\n完整命令见根目录 `README.md`。所有配置固定后逐 seed 保存 checkpoint 哈希；新增运行保存可复算的 logits 和标签。标签只在评分回调中读取，不进入适配器输入与损失。',
      '\n## TT-GREB 核心公式',
      '\n四个 MLP 输出原型与环境的特征权重 $P_X,E_X$ 和边权重 $P_A,E_A$。',
      '\n'+r'$$W_X=P_X+(1-P_X)\odot E_X,\quad W_A=P_A+(1-P_A)\odot E_A$$',
      '\n'+r'$$X_{new}=X\odot W_X,\quad a_{new}=a\odot W_A$$',
      '\n'+r'$$R(W,\lambda)=\left|\frac{\sum W}{\sum(1-W)}-\lambda\right|$$',
      '\n'+r'$$L_{pro}=\sum_i[1-\cos(Z_{new,i},Z_{pro,i})]-\sum_i[1-\cos(Z_{env,i},Z_{pro,i})]+\alpha[R(P_X,\lambda_1)+R(P_A,\lambda_2)]$$',
      '\n'+r'$$J_{env}=\|Z_0-Z_{env}\|_F^2-\beta[R(E_X,\lambda_3)+R(E_A,\lambda_4)]$$',
      '\n骨干及 BatchNorm 统计量冻结。每轮先对原型模块下降 $L_{pro}$，再对环境模块上升 $J_{env}$，使用两个 Adam。每个测试图重新初始化适配器。公式依据本地 ICLR 2025 匿名审稿版式 5–8；ICDM 正式版全文与作者实现仍未直接核实。',
      '\n只特征消融固定边权为 1，并从正则中移除对应分支；只边消融相反。完整模式已用小图测试确认与保留的原核心逐元素一致。零步重组使用同一初始化与种子，仅不执行优化器更新。',
      '\n## 统一固定配置结果',
      '\n选参使用验证集 seeds 0/1/2，统一测试使用 seeds 0–9。历史测试已经见过，当前结果属于扩展复现实验，不能称全新盲测。标准差采用样本标准差（ddof=1）。',
      '\n| 数据集 | 骨干 | n/10 | 本地 ERM | 零步重组 | 完整适配 | 配对提升 pp | 实际更新收益 pp |',
      '|---|---|---:|---:|---:|---:|---:|---:|']
    allrows=[];coverage={};summary=[];environment=[]
    for d in s.ALL_DATASETS:
      for m in s.MODELS:
        rows=[s.read(p) for p in sorted((s.ART/d/m/'confirmed/both').glob('seed*/summary.json'))]
        coverage[f'{d}/{m}']=[r['seed'] for r in rows]
        if not rows:
            lines.append(f'| {d} | {m} | 0 | — | — | — | — | — |');continue
        if len({r['locked_sha256'] for r in rows})!=1:raise RuntimeError('Mixed configurations')
        for r in rows:
            if r['graphs']!={'cora':8,'amazon_photo':8,'elliptic':33,'twitch':5}[d]:raise RuntimeError('Incomplete environments')
            if not r['backbone_unchanged']:raise RuntimeError('Backbone mutated')
            if abs(r['delta']-(r['adapted']-r['baseline']))>1e-12:raise RuntimeError('Wrong paired delta')
            allrows.append({k:r[k] for k in ('dataset','model','seed','baseline','zero','adapted','delta','update_delta','graphs','checkpoint_sha256','locked_sha256','source_reused')})
            source=s.ART/d/m/'confirmed/both'/f'seed{r["seed"]}'
            graphrows=r.get('per_graph')
            if graphrows is None:graphrows=[s.read(source/f'graph{i}.json') for i in range(r['graphs'])]
            for g in graphrows:environment.append(dict(dataset=d,model=m,seed=r['seed'],graph=g['graph'],
                domain=g.get('domain'),time_step=g.get('time_step'),environment=g.get('environment'),
                baseline=g['baseline'],zero=g['zero'],adapted=g['adapted'],delta=g['adapted']-g['baseline']))
        lines.append(f'| {d} | {m} | {len(rows)} | '+ ' | '.join(fmt([r[k] for r in rows]) for k in ('baseline','zero','adapted','delta','update_delta'))+' |')
        delta=[r['delta'] for r in rows];se=statistics.stdev(delta)/math.sqrt(len(delta)) if len(delta)>1 else 0
        summary.append(dict(dataset=d,model=m,n=len(rows),baseline=avg(rows,'baseline'),zero=avg(rows,'zero'),adapted=avg(rows,'adapted'),
            delta=avg(rows,'delta'),update_delta=avg(rows,'update_delta'),positive_seeds=sum(v>0 for v in delta),
            paired_delta_std=statistics.stdev(delta) if len(delta)>1 else 0,
            descriptive_t9_ci95=[avg(rows,'delta')-2.262*se,avg(rows,'delta')+2.262*se] if len(delta)==10 else None))
    lines+=['\n主表提升始终为同一个本地 checkpoint 的“适配 − ERM”；实际更新收益为“适配 − 零步”。只提高于 ERM 而未提高于零步，不能说明交替优化带来了正收益。',
       '\n## 模块消融：固定相同超参数，seeds 0/1/2',
       '\n消融不重新选参；比较同一骨干 checkpoint。',
       '\n| 数据集 | 骨干 | 模式 | n/3 | ERM | 零步 | 适配 | 配对提升 pp | 更新收益 pp |',
       '|---|---|---|---:|---:|---:|---:|---:|---:|']
    ablations=[]
    for d in s.ALL_DATASETS:
      for m in s.MODELS:
        for mode in ('features','edges','both'):
          base=s.ART/d/m/('confirmed' if mode=='both' else 'module_ablation')/mode
          rows=[s.read(p) for p in sorted(base.glob('seed*/summary.json')) if int(p.parent.name[4:])<3]
          if rows:
            lines.append(f'| {d} | {m} | {mode} | {len(rows)} | '+' | '.join(fmt([r[k] for r in rows]) for k in ('baseline','zero','adapted','delta','update_delta'))+' |')
            ablations.extend(dict(dataset=d,model=m,mode=mode,seed=r['seed'],baseline=r['baseline'],zero=r['zero'],adapted=r['adapted'],delta=r['delta'],update_delta=r['update_delta'],checkpoint_sha256=r['checkpoint_sha256']) for r in rows)
    lines+=['\n## Elliptic：同一预测的三种汇总',
      '\n历史 v4 精确还原 1782 个整数混淆矩阵，逐一复核 precision、recall、F1、预测阳性比例与原主表。它们是 F1 汇总的充分统计量，无须改预测或重跑适配。非法类为标签 1。',
      '\n| 骨干/角色 | 方法 | n | 33 时间均值 | GTrans 9 分组均值 | 合并宏 F1 | 合并非法类 F1 | 合并非法类召回 |',
      '|---|---|---:|---:|---:|---:|---:|---:|']
    audit=s.read(out/'metric_audit.json')
    for m,role in (('gcn','primary'),('gcn','old_fixed'),('graphsage','primary')):
      for method in ('baseline','zero','adapted'):
        rs=[r for r in audit['records'] if r['model']==m and r['role']==role and r['method']==method]
        lines.append(f'| {m}/{role} | {method} | {len(rs)} | '+' | '.join(f'{avg(rs,k)*100:.4f}' for k in ('time_mean','gtrans9_mean','pooled_macro','pooled_illicit_f1','pooled_illicit_recall'))+' |')
    lines+=['\n9 分组索引为 `[0]、[1..4]、…、[29..32]`。另保存 GTrans 先将分组分数保留两位小数再平均的结果，主对照不提前舍入。汇总改变绝对分数，未消除 v4 GraphSAGE 退化。TT-GREB 作者是否完全沿用分组仍无直接证据。',
      '\n## 引用设置基线复核',
      '\n独立训练 4×2×3 个引用设置对照：200 轮、隐藏维度 32、dropout 0、BatchNorm；GCN/SAGE 有效学习率按 GTrans 预训练入口取值。Elliptic 为 5 层、BCE、每轮平均 5 图损失后一次更新，验证节点合并选择 checkpoint。',
      '\nGraphSAGE 使用引用代码的 `torch.nn.Linear` 初始化、邻居平均前偏置及第二次 reset；GCN 使用 PyG 实现。当前 PyTorch/PyG 版本与原依赖环境不同，且数据环境生成的原随机状态未核实，因此属于可核实引用设置对照，不宣称逐位复现 TT-GREB 作者源码。',
      '\n| 数据集 | 骨干 | n/3 | 引用设置本地 ERM | 论文 ERM | 论文 TT-GREB | 论文提升 pp |',
      '|---|---|---:|---:|---:|---:|---:|']
    reference_rows=[]
    for d in s.ALL_DATASETS:
      for m in s.MODELS:
        rs=[s.read(p) for p in sorted((s.ART/d/m/'reference_aligned').glob('seed*/summary.json'))]
        pb,pa=PAPER[d,m]
        lines.append(f'| {d} | {m} | {len(rs)} | {fmt([r["test"]["mean"] for r in rs])} | {pb:.2f} | {pa:.2f} | {pa-pb:+.2f} |')
        reference_rows.extend(dict(dataset=d,model=m,seed=r['seed'],mean=r['test']['mean'],pooled=r['test']['pooled'],checkpoint_sha256=r['checkpoint_sha256']) for r in rs)
    lines+=['\n论文表来自本地 ICLR 2025 匿名审稿版表 1，正文为 10 次随机重复；不能把论文 ERM 作为本地提升的分母或配对起点。Cora/Amazon 源图使用全部节点标签训练，同节点跨环境评估，不是标准节点留出准确率；引用设置对照仍可能达到很高分数。',
      '\n## 诊断与配置',
      '\n验证搜索保留上一轮锁定设置，受控比较初始化概率 0.7/0.9/0.97/0.995、初始化末层尺度 0.1/1/3、步数 1/3/5/10（旧配置含 20）及正则系数。每个设置先 seed0 轨迹筛选，再用前三个不同设置加旧锁定设置在 seeds0/1/2 确认。没有使用测试分数重选。',
      '\n| 数据集 | 骨干 | 步数 | 适配 lr | alpha | beta | 初始概率 | 末层尺度 |',
      '|---|---|---:|---:|---:|---:|---:|---:|']
    for d in s.ALL_DATASETS:
      for m in s.MODELS:
        path=s.ART/d/m/'locked.json'
        if path.exists():
          locked=s.read(path);o=locked['options']
          lines.append(f'| {d} | {m} | {o["steps"]} | {o["lr"]} | {o["alpha"]} | {o["beta"]} | {o.get("init_probability")} | {o.get("init_gain",.1)} |')
          s.save(s.ROOT/f'configs/locked/{d}_{m}.json',locked)
    lines+=['\n初始化概率 p 同时作用于两路时，组合期望接近 `1-(1-p)^2`；如 p=0.995 时接近 0.999975。这样的结果接近 ERM，应同时看权重标准差、相对零步收益与 AUC 实际变化，不能仅以“没有下降”宣称适配有效。完整逐步 loss、权重均值/标准差、分支梯度和参数变化均保存在 artifacts。',
      '\n初步接线的 `artifacts/*/*/reference` 与 `final`、`ablation` 被保留作开发记录；引用对照主表只读 `reference_aligned`，最终主表只读 `confirmed`，消融只读 `module_ablation`。确认批次显式统一旧配置的早停规则，避免用训练上限相同掩盖实际调度差异。',
      '\n## 完成与审计',
      '\n细表见 [逐种子结果](reports/paired_seeds.csv)、[逐环境结果](reports/per_environment.csv)、[模块消融](reports/module_ablation.csv)、[引用设置基线](reports/reference_baselines.csv)。完整性见 [completion.json](reports/completion.json)，逐预测重算与历史保存核验见 [final_audit.json](reports/final_audit.json)。评分出处、源码快照和哈希见 [证据说明](reports/REFERENCE_EVIDENCE.md) 与 `reports/reference_sources/`。']
    lines+=['\n## 本轮结论',
      '\n| 数据集 | 骨干 | 完整适配对 ERM（pp） | 更新相对零步（pp） | 正收益种子 |',
      '|---|---|---:|---:|---:|']
    for row in summary:
        lines.append(f'| {row["dataset"]} | {row["model"]} | {100*row["delta"]:+.4f} | {100*row["update_delta"]:+.4f} | {row["positive_seeds"]}/{row["n"]} |')
    lines+=['\n宏 F1 的汇总方式会改变绝对值，但不是 GraphSAGE 退化的全部原因。零步与 ERM 的差反映初始化重组的影响；适配与零步的差才反映本轮更新效果。无监督表示目标没有直接最优化测试 F1/AUC，因此参数发生更新不等于分类指标必然改善。',
      '\nElliptic 的 10 种子完整模式中，GCN 相对 ERM 提升约 0.2709 pp，但相对零步下降约 0.0572 pp；GraphSAGE 的零步已较 ERM 下降约 1.8064 pp，更新后总下降约 1.8240 pp。相同前三种子的仅特征模式下降约 1.4484 pp，而仅边模式变化约 0.0002 pp，支持先排查特征缩放导致的少数类预测减少；最终预测的非法类召回已在汇总表中列出。消融分支数量不同，不能将其差值直接解释为严格可加的因果贡献。',
      '\nAmazon GCN 的前三种子完整模式下降约 0.4319 pp，仅特征下降约 0.4254 pp，仅边提升约 0.0414 pp；扩大到 10 种子后完整模式下降约 0.7910 pp。因此前三种子的验证收益没有稳定迁移到测试，不能用单次最好值替换主表。Twitch 则应结合接近恒等的组合权重和近乎不变的 AUC 排序解释，当前证据不支持宣称获得了实质提升。',
      '\n固定配置消融比较的是模块在相同设置下的贡献，不代表为每个消融重新调参后的最高分。GraphSAGE 的邻居均值会抵消近似常数的边权缩放，近恒等特征权重也难以改变 AUC 排序。对高基线、弱偏移和初始化抑制少数类预测，应分别结合逐环境表、非法类召回和零步对照解释。',
      '\nCora/Amazon 主配置继承历史容量搜索，曾比较隐藏维度、dropout 与验证适配收益，因此属于经过调参的扩展配置，不是论文默认骨干；原始配置和本轮引用设置对照均另行保留。本轮不再依据测试分数降低基线或筛选种子，完整保留负收益。仍未稳定改善的组合应作为复现差距报告，后续若改变损失、重加权参数化或引入图提示，应另立扩展实验。']
    diagnostics=[]
    for d in s.ALL_DATASETS:
      for m in s.MODELS:
        for p in (s.ART/d/m/'confirmed/both').glob('seed*/graph*.json'):
          g=s.read(p)
          if 'final_weights' not in g:continue
          initial=g['initial_weights']['composed'];final=g['final_weights']['composed']
          diagnostics.append(dict(dataset=d,model=m,seed=int(p.parent.name[4:]),graph=g['graph'],
            initial_feature_mean=initial['feature_mean'],final_feature_mean=final['feature_mean'],feature_std=final['feature_std'],
            initial_edge_mean=initial['edge_mean'],final_edge_mean=final['edge_mean'],edge_std=final['edge_std'],
            updated_branches=g['diagnostics']['updated_branches'],baseline=g['baseline'],zero=g['zero'],adapted=g['adapted']))
    lines+=['\n新运行图的组合权重统计见 `reports/weight_diagnostics.csv`，复用的历史结果不补造未保存的权重。']
    final_aggregations=[]
    for m in s.MODELS:
      for p in (s.ART/'elliptic'/m/'confirmed/both').glob('seed*/summary.json'):
        row=s.read(p)
        if 'aggregation' in row:
            values=row['aggregation']
        elif row['source_reused']:
            source=Path(row['source']).parent
            old=[s.read(source/f'graph{i}.json') for i in range(33)]
            values={method:aggregations([confusion_from_record(g[method]) for g in old]) for method in ('baseline','zero','adapted')}
        else:raise RuntimeError('Missing final Elliptic aggregation evidence')
        final_aggregations.extend(dict(model=m,seed=row['seed'],method=method,**{k:v for k,v in metrics.items() if k!='grouped_macro'}) for method,metrics in values.items())
    if final_aggregations:
        lines+=['\n## 最终配置 Elliptic 汇总对照',
          '\n每个 seed 使用同一套预测，逐时间、分组和合并分别重算；不同列不能混合作为配对起点。',
          '\n| 骨干 | 方法 | n | 时间均值 | 9 组均值 | 合并宏 F1 | 合并非法类 F1 | 合并非法类召回 |',
          '|---|---|---:|---:|---:|---:|---:|---:|']
        for m in s.MODELS:
          for method in ('baseline','zero','adapted'):
            rs=[r for r in final_aggregations if r['model']==m and r['method']==method]
            if rs:lines.append(f'| {m} | {method} | {len(rs)} | '+' | '.join(fmt([r[k] for r in rs]) for k in ('time_mean','gtrans9_mean','pooled_macro','pooled_illicit_f1','pooled_illicit_recall'))+' |')
    lines+=['\n## 骨干训练配置',
       '\n| 数据集 | 骨干 | 层数 | 隐藏维度 | dropout | BN | 学习率 | 轮数上限 | 最少轮数/耐心 |',
       '|---|---|---:|---:|---:|---|---:|---:|---:|']
    for d in s.ALL_DATASETS:
      for m in s.MODELS:
        locked=s.read(s.ART/d/m/'locked.json');c=s.canonical_config(locked['config'])
        effective=dict(dataset=d,model=m,config=c,adapter={**locked['options'],'init_gain':locked['options'].get('init_gain',.1)},
            training_graph_update='one optimizer step per training graph',validation_selection='mean over validation graphs',
            seeds=list(range(10)),selection_seeds=[0,1,2],test_used_for_selection=False)
        s.save(s.ROOT/f'configs/effective/{d}_{m}.json',effective)
        mo,tr=c['model'],c['training']
        lines.append(f'| {d} | {m} | {mo["num_layers"]} | {mo["hidden_channels"]} | {mo["dropout"]} | {mo["batch_norm"]} | {tr["learning_rate"]} | {tr["max_epochs"]} | {tr["minimum_epochs"]}/{tr["patience"]} |')
    complete=all(sorted(v)==list(range(10)) for v in coverage.values())
    ablate_complete=len(ablations)==72
    ref_complete=len(reference_rows)==24
    checks=dict(final_8_pairs_10_seeds=complete,expected_final_seed_records=80,actual_final_seed_records=len(allrows),
        module_8_pairs_3_modes_3_seeds=ablate_complete,reference_8_pairs_3_seeds=ref_complete,
        coverage=coverage,all_completed=complete and ablate_complete and ref_complete,
        metric_confusions_verified=audit['reconstructed_confusions'],historical_results_unchanged='run run_study.py initialize to verify preservation manifest')
    position=lines.index('\n## 完成与审计')+1
    lines.insert(position, f'\n当前完成：主实验 {len(allrows)}/80 条配对种子记录（每条含 ERM、零步、完整适配）；仅特征/仅边新增消融 {sum(r["mode"]!="both" for r in ablations)}/48 条，完整模式消融复用前三种子；独立引用设置基线 {len(reference_rows)}/24 条。7 项行为测试及独立目录的 Cora 训练/适配检查已通过。')
    (out/'completion.json').write_text(json.dumps(checks,indent=2),encoding='utf8')
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    (s.ROOT/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
    write_csv(out/'paired_seeds.csv',allrows);write_csv(out/'per_environment.csv',environment)
    write_csv(out/'module_ablation.csv',ablations);write_csv(out/'reference_baselines.csv',reference_rows)
    write_csv(out/'weight_diagnostics.csv',diagnostics)
    write_csv(out/'final_elliptic_aggregations.csv',final_aggregations)
    print(json.dumps(checks,indent=2))


if __name__=='__main__':main()
