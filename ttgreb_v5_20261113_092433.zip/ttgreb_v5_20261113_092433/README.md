# TT-GREB 四数据集复现

本目录是可以单独运行和上传的项目。研究范围：Cora、Amazon-Photo、Elliptic、Twitch-E × GCN、GraphSAGE；暂不含图提示。原始实验保留在父目录，本目录不依赖同学的三个源码工程。

最终结果、核心公式、实验说明见 [RESULTS.md](RESULTS.md)。逐种子、逐环境及消融表位于 `reports/`。本地完整日志、预测和模型保存在 `artifacts/`，默认不上传 GitHub。

## 环境

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

本地实验为 Python 3.13.5、PyTorch 2.9.1 CPU；实际依赖版本保存在 `reports/environment.json`。适配使用可微稀疏算子，不依赖 torch_sparse 扩展。程序默认单 CPU 线程，每个图重新初始化适配器。

## 数据位置

下载和预处理后的数据通过 `--data-root` 指定，不随代码上传，不会自动更改或重划分。

```text
data_root/
  Planetoid/cora/processed/data.pt
  Planetoid/cora/gen/0-gat.pkl ... 9-gat.pkl
  Amazon/Photo/processed/data.pt
  Amazon/Photo/gen/0-gcn.pkl ... 9-gcn.pkl
  elliptic/6.pkl ... 48.pkl
  twitch/DE/ ... ENGB/ ES/ FR/ PTBR/ RU/ TW/
```

Cora/Amazon 按环境 0/1/2–9，即 1/1/8 分图；同一批节点跨环境，源图使用全部已知标签，不等同于标准节点留出测试。Elliptic 为时间 6–10 训练、11–15 验证、16–48 测试，未知类不计分；Twitch 为 DE 训练、ENGB 验证、其余五域测试。

## 固定配置复跑

从本目录运行，替换实际数据位置。已有 `configs/locked/` 时读取已发布配置，不再根据测试结果选参；同一运行目录可以断点继续，完整结果文件不会被覆盖。

```powershell
python -X utf8 run_study.py initialize
python -X utf8 run_study.py final --data-root "D:\大三上\数据挖掘-GNN\data\data"
python -X utf8 run_study.py ablate --data-root "D:\大三上\数据挖掘-GNN\data\data"
python -X utf8 run_study.py reference --data-root "D:\大三上\数据挖掘-GNN\data\data"
python -X utf8 report.py
```

只检查一组，可限定数据、模型和种子：

```powershell
python -X utf8 run_study.py final --datasets cora --models gcn --seeds 0 --data-root "你的数据目录"
python -X utf8 -m unittest discover -s tests -v
```

主实验 8 组 × 10 seeds，分别记录 ERM、相同随机初始化的零步重组和完成交替更新后的适配结果。消融为 8 组 × 3 seeds × 仅特征/仅边，并与完整模式相同三个 seeds 配对比较。引用设置基线为 8 组 × 3 seeds，与改进配置分开记录。

`run_study.py tune` 的新搜索只在缺少已锁定配置时启动；如需新研究，请复制为独立实验目录，保留当前 `configs/locked` 和 `artifacts`，避免覆盖已报告结果。配置仍需经过验证集确认后再测试。

## 评分与证据

Elliptic 主指标为 33 时间片等权宏 F1，另列同一预测的 GTrans 9 分组和节点合并宏 F1，并单列非法类 F1/召回。评分口径对照不改变原预测。多种子表使用样本标准差，保留负收益和接近零的结果；相对零步的收益单独报告。

公式依据本地 ICLR 2025 匿名审稿版；ICDM 最终版和作者实现尚未直接核实。引用设置基线依据 GTrans 公开代码，有源码快照与哈希，不将其冒称为作者最终设置。独立引用对照复核了多图损失先平均再更新、合并验证、GraphSAGE 的偏置位置和初始化。

## 上传 GitHub 分支

将整个 `release_v5` 目录作为新分支中的独立项目根目录。应提交源码、配置、测试、README、RESULTS 和 `reports/`；`.gitignore` 已排除数据、checkpoint、预测和本地虚拟环境。完整研究记录仍留在当前工作区，未删除。

```powershell
git switch -c ttgreb-reproduction-v5
git add .
git status --short
git commit -m "Add four-dataset TT-GREB reproduction and supplementary experiments"
git push -u origin ttgreb-reproduction-v5
```

以上命令在你已经配置好远程仓库的工作副本中执行。本地若无 Git 或尚无 remote，只生成可上传代码包，不自动猜测仓库地址。
