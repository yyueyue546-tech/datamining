"""Explicit GTrans-derived reference controls, separate from improved configurations."""
from copy import deepcopy
from pathlib import Path
import statistics
import time
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from sklearn.metrics import confusion_matrix
import run_study as s
from metrics_audit import aggregations


class ReferenceMeanConv(nn.Module):
    """GTrans models/sage.py: linear including bias BEFORE neighbor mean.

    Native PyG mean SAGE adds the bias after mean. The difference matters for
    nodes without incoming edges, so the reference control makes it explicit.
    """
    def __init__(self, incoming, outgoing):
        super().__init__()
        self.lin_l=nn.Linear(incoming,outgoing,bias=True)
        self.lin_r=nn.Linear(incoming,outgoing,bias=False)
        self.lin_l.reset_parameters(); self.lin_r.reset_parameters()

    def forward(self,x,edge):
        src,dst=edge
        degree=torch.bincount(dst,minlength=x.size(0)).to(x).clamp_min(1)
        adj=torch.sparse_coo_tensor(edge.flip(0),degree[dst].reciprocal(),(x.size(0),x.size(0)))
        return torch.sparse.mm(adj,self.lin_l(x))+self.lin_r(x)


class ReferenceSAGE(nn.Module):
    def __init__(self,incoming,classes,opts):
        super().__init__()
        dims=[incoming]+[opts['hidden_channels']]*(opts['num_layers']-1)+[classes]
        self.convs=nn.ModuleList();self.bns=nn.ModuleList()
        for i,(a,b) in enumerate(zip(dims,dims[1:])):
            self.convs.append(ReferenceMeanConv(a,b))
            if i<len(dims)-2:self.bns.append(nn.BatchNorm1d(b))
        self.dropout=opts['dropout'];self.with_bn=opts['batch_norm']

    def forward(self,x,edge,edge_weight=None):
        if edge_weight is not None:raise ValueError('Reference is ERM-only')
        for i,conv in enumerate(self.convs):
            x=conv(x,edge)
            if i<len(self.convs)-1:
                if self.with_bn:x=self.bns[i](x)
                x=F.dropout(F.relu(x),p=self.dropout,training=self.training)
        return x


def reference_update(model, graphs, classes, optimizer, loss_name):
    """One optimizer step on the mean graph loss, as in the cited source."""
    optimizer.zero_grad(set_to_none=True)
    losses=[]
    for g in graphs:
        y,mask=s.labels_and_mask(g);target=torch.searchsorted(classes,y[mask])
        logits=model(g.x,g.edge_index)[mask]
        if loss_name=='cross_entropy':loss=F.cross_entropy(logits,target)
        else:loss=F.binary_cross_entropy_with_logits(logits,F.one_hot(target,len(classes)).to(logits))
        losses.append(loss)
    loss=torch.stack(losses).mean()
    if not torch.isfinite(loss):raise RuntimeError('Nonfinite reference training loss')
    loss.backward();optimizer.step()
    return loss.detach()


def run_reference(dataset,name,raw):
    config=deepcopy(s.yaml.safe_load((s.ROOT/f'configs/backbones/{dataset}.yaml').read_text(encoding='utf8'))[name])
    config['implementation']='gtrans_snapshot_mean_graph_loss_single_update_v1'
    config['training'].update(minimum_epochs=200,patience=500,validation_metric=s.METRICS[dataset],
        class_balance='none',update_rule='mean_graph_losses_then_one_step')
    config['preprocessing']=dict(undirected=False,feature_norm='none')
    s.save(s.ROOT/f'configs/reference/{dataset}_{name}.json',config)
    results=[]
    for seed in (0,1,2):
        folder=s.ART/dataset/name/'reference_aligned'/f'seed{seed}'
        if (folder/'summary.json').exists():results.append(s.read(folder/'summary.json'));continue
        start=time.perf_counter();s.seed_everything(seed)
        classes=torch.cat([g.y[s.labels_and_mask(g)[1]] for g in raw['train']]).unique()
        model=ReferenceSAGE(raw['train'][0].num_features,len(classes),config['model']) if name=='graphsage' else s.build_model(name,raw['train'][0].num_features,len(classes),config['model'])
        # GTrans fit_inductive(initialize=True) resets the completed model again.
        if name=='graphsage':
            for conv in model.convs:conv.lin_l.reset_parameters();conv.lin_r.reset_parameters()
            for bn in model.bns:bn.reset_parameters()
        else:model.reset_parameters()
        opt=torch.optim.AdamW(model.parameters(),lr=config['training']['learning_rate'],weight_decay=config['training']['weight_decay'])
        best=None
        for epoch in range(1,201):
            model.train()
            loss=reference_update(model,raw['train'],classes,opt,config['training']['loss'])
            model.eval()
            val=s.evaluate(model,raw['valid'],classes,dataset)
            selected=val['pooled'] if dataset=='elliptic' else val['mean']
            if best is None or selected>best['selection_score']:
                best=dict(best_epoch=epoch,selection_score=selected,validation=val,
                    model_state_dict={k:v.detach().clone() for k,v in model.state_dict().items()})
            s.log(folder/'history.jsonl',dict(epoch=epoch,loss=float(loss.detach()),validation=selected,best=best['selection_score']))
        model.load_state_dict(best['model_state_dict']);model.eval()
        cp=folder/'checkpoint.pt'
        if cp.exists():cp=folder/f'checkpoint_retry{time.time_ns()}.pt'
        torch.save(dict(dataset=dataset,model=name,seed=seed,config=config,classes=classes.tolist(),
                   in_channels=raw['train'][0].num_features,**best),cp)
        result=dict(dataset=dataset,model=name,seed=seed,config=config,test=s.evaluate(model,raw['test'],classes,dataset),
            checkpoint_sha256=s.digest(cp),checkpoint=str(cp),best_epoch=best['best_epoch'],validation=best['validation'],
            validation_selection='pooled' if dataset=='elliptic' else 'time_mean',seconds=time.perf_counter()-start,
            provenance='cited GTrans main snapshot, not independently verified TT-GREB final implementation')
        cs=[]
        for i,g in enumerate(raw['test']):
            logits,y,pred=s.predict_graph(model,g,classes)
            np.savez_compressed(folder/f'predictions{i}.npz',logits=logits.numpy(),labels=y.numpy(),classes=classes.numpy())
            if dataset=='elliptic':cs.append(confusion_matrix(y,pred,labels=[0,1]).tolist())
        if cs:result['aggregation']=aggregations(cs)
        s.save(folder/'summary.json',result);results.append(result)
        print(f'ALIGNED REFERENCE {dataset}/{name}/s{seed} test={result["test"]["mean"]:.6f} sec={result["seconds"]:.1f}',flush=True)
    return results


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--datasets',nargs='+',default=list(s.ALL_DATASETS));p.add_argument('--data-root',type=Path,default=s.WORKSPACE/'data/data')
    args=p.parse_args()
    for d in args.datasets:
        raw=s.load_data(args.data_root,d)
        for m in s.MODELS:run_reference(d,m,raw)
