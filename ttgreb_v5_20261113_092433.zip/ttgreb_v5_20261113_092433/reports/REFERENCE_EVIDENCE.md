# 公式、评分和引用设置的证据范围

## TT-GREB 公式与论文表

本地核对的是 ICLR 2025 匿名审稿版 *Test-Time Graph Rebirth for GNN Generalization Under Distribution Shifts*。PDF SHA256：

`fb5f5a7f5e24ae696ae8655073fb464dd463e1a2e455d270af013726e4582660`

公式（5）—（8）在 PDF 第 7 页核对；主结果表 1 位于第 8 页；附录 A1 第 15 页仅写 Elliptic 为 “F1 Score”，没有直接注明类别平均和时间片汇总细节。正文说明重复十个随机种子。

正式发表 DOI：https://doi.org/10.1109/ICDM65498.2025.00105 。本轮没有直接核实 ICDM 最终版全文或找到可核实的作者实现。因此不能将本地实现、引用代码的全部设置或宏 F1 时间汇总方式称为“已由 TT-GREB 官方源码确认”。

## 宏 F1 与时间片汇总

引用工作 GTrans 作者仓库：https://github.com/ChandlerBang/GTrans 。本轮基于其 main 分支下载快照，文件 URL、下载状态和 SHA256 在 `reference_sources/sources_*.json`；没有取得 commit SHA。

- `utils.py::eval_f1` 使用 sklearn `average='macro'`。
- `train_both_all.py` 在 `i % 4 == 0` 或最后一张测试图时合并预测评分；33 张图形成 `[0]、[1..4]、…、[29..32]` 共 9 组，并在组均值前保留评分两位小数。
- `models/base_model.py` 在 Elliptic 验证时拼接五图预测与标签，再计算宏 F1。

上述评分源码早先保存在历史 `experiments/metric_audit`。本交付的 `metric_audit.json` 保存精确核验后的整数混淆矩阵及重新汇总数值；`final_elliptic_aggregations.csv` 保存最终配置的三种汇总和非法类 F1/召回。类别宏平均和时间汇总是两个独立选择。

## 本轮引用设置基线

`reference_sources/gtransform_feat.py::pretrain_model`、`models_base_model.py`、`models_gcn.py`、`models_sage.py` 可直接核对实际构造参数与训练更新。

- Cora/Amazon：两层、隐藏 32、dropout 0；GCN 学习率 0.001，SAGE 的有效构造学习率为 0.01。
- Elliptic：五层、隐藏 32、dropout 0、BCE、学习率 0.01、weight decay 0。
- Twitch：两层、隐藏 32、dropout 0、BCE、学习率 0.01、weight decay 0.001。
- 使用 AdamW、200 轮、验证选 checkpoint；预训练入口的 patience=500，不会在 200 轮内触发。
- Elliptic 在一个 epoch 中先平均五张训练图的损失，再执行一次更新；与改进配置的逐图更新分开记录。
- GTrans SAGE 的线性层在邻居平均前加入偏置，并使用 `torch.nn.Linear` 的初始化，再由 `fit_inductive` reset；孤立节点与默认 PyG SAGE 可能不同。

它们构成可核实的引用设置对照。当前依赖版本、数据环境生成随机状态与原 TT-GREB 最终实现尚未完全对齐，不能据此声称作者实验已精确复现。论文表与本地表分别展示，配对适配提升始终使用同一本地 checkpoint。


???????????????? `reference_sources/gtrans_utils.txt`?`gtrans_train.txt` ??????? `metric_audit_*sources*.json`?????? SHA256 ????? `metric_audit_import_manifest.json`?????????? macro F1 ? 9 ?????
