from .gcn import GCN
from .graphsage import GraphSAGE


def build_model(name, in_channels, num_classes, options):
    model = {"gcn": GCN, "graphsage": GraphSAGE}[name](
        in_channels, out_channels=num_classes, **options)
    model.out_channels = num_classes
    return model
