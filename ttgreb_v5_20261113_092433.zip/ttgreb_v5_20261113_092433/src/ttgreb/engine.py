"""Training, checkpoint reconstruction and label-free adaptation."""
from pathlib import Path
import random
import time

import numpy as np
import torch
from sklearn.metrics import f1_score, roc_auc_score
from torch.nn import functional as F

from .models import build_model
from .adapter import adapt_reweight


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def labels_and_mask(graph):
    labels = graph.y.reshape(-1).long()
    mask = labels >= 0
    if getattr(graph, "mask", None) is not None:
        mask &= graph.mask.reshape(-1).bool()
    if not mask.any():
        raise ValueError("No labeled evaluation/training nodes")
    return labels, mask


def score_logits(logits, labels, classes, metric, positive_class=1):
    logits, labels, classes = logits.detach().cpu(), labels.cpu(), classes.cpu()
    predictions = classes[logits.argmax(-1)]
    if metric == "accuracy":
        return float((predictions == labels).float().mean())
    if metric in ("f1_macro", "f1_binary"):
        options = {"average": "macro"} if metric == "f1_macro" else {
            "average": "binary", "pos_label": positive_class}
        return float(f1_score(labels.numpy(), predictions.numpy(), zero_division=0, **options))
    if metric == "roc_auc":
        indices = (classes == positive_class).nonzero().reshape(-1)
        if indices.numel() != 1:
            raise ValueError(f"Positive class {positive_class} absent from training encoding")
        probability = logits.softmax(-1)[:, int(indices[0])]
        return float(roc_auc_score((labels == positive_class).numpy(), probability.numpy()))
    raise ValueError(metric)


@torch.no_grad()
def evaluate(model, graphs, classes, metric, device, positive_class=1):
    model.eval()
    scores, all_logits, all_labels = [], [], []
    for original in graphs:
        graph = original.clone().to(device)
        labels, mask = labels_and_mask(graph)
        logits = model(graph.x, graph.edge_index, getattr(graph, "edge_weight", None))[mask]
        labels = labels[mask]
        scores.append(score_logits(logits, labels, classes, metric, positive_class))
        all_logits.append(logits.cpu())
        all_labels.append(labels.cpu())
    return {"mean": float(np.mean(scores)), "std_across_graphs": float(np.std(scores)),
            "per_graph": scores,
            "pooled": score_logits(torch.cat(all_logits), torch.cat(all_labels), classes, metric, positive_class)}


def fit(splits, model_name, config, seed, device, epochs):
    seed_everything(seed)
    classes = torch.cat([labels_and_mask(g)[0][labels_and_mask(g)[1]] for g in splits["train"]]).unique()
    if classes.numel() < 2:
        raise ValueError("Training graphs must contain at least two classes")
    model = build_model(model_name, splits["train"][0].num_features,
                        classes.numel(), config["model"]).to(device)
    options = config["training"]
    loss_name = options["loss"]
    if loss_name not in ("cross_entropy", "bce_with_logits"):
        raise ValueError(f"Unsupported loss {loss_name}")
    optimizer_class = {"Adam": torch.optim.Adam, "AdamW": torch.optim.AdamW}[options["optimizer"]]
    optimizer = optimizer_class(model.parameters(), lr=options["learning_rate"],
                                weight_decay=options["weight_decay"])
    classes_device = classes.to(device)
    best = None
    for epoch in range(1, epochs + 1):
        model.train()
        for original in splits["train"]:
            graph = original.clone().to(device)
            labels, mask = labels_and_mask(graph)
            targets = torch.searchsorted(classes_device, labels[mask])
            optimizer.zero_grad(set_to_none=True)
            logits = model(graph.x, graph.edge_index, getattr(graph, "edge_weight", None))[mask]
            if loss_name == "bce_with_logits":
                loss = F.binary_cross_entropy_with_logits(
                    logits, F.one_hot(targets, num_classes=classes.numel()).to(logits.dtype))
            else:
                loss = F.cross_entropy(logits, targets)
            if not torch.isfinite(loss):
                raise ValueError(f"Nonfinite loss at epoch {epoch}")
            loss.backward()
            optimizer.step()
        validation = evaluate(model, splits["valid"], classes, options["validation_metric"], device)
        if best is None or validation["mean"] > best["validation"]["mean"]:
            best = {"best_epoch": epoch, "validation": validation,
                    "model_state_dict": {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}}
        if epoch == 1 or epoch % 25 == 0 or epoch == epochs:
            print(f"epoch={epoch} val={validation['mean']:.6f} best={best['validation']['mean']:.6f}")
    model.load_state_dict(best["model_state_dict"])
    model.eval().requires_grad_(False)
    return model, classes, best


def load_checkpoint(path, device, dataset, model_name):
    # Accept the metadata + model_state_dict schema written by jwj train.py.
    payload = torch.load(Path(path), map_location="cpu", weights_only=False)
    required = {"dataset", "model", "config", "in_channels", "classes", "model_state_dict"}
    if not isinstance(payload, dict) or not required.issubset(payload):
        raise ValueError("Checkpoint needs model_state_dict and architecture metadata (jwj/integrated format)")
    if payload["dataset"] != dataset or payload["model"] != model_name:
        raise ValueError("Checkpoint dataset/model does not match the requested experiment")
    classes = torch.tensor(payload["classes"], dtype=torch.long)
    if classes.numel() < 2 or not torch.equal(classes, classes.unique()):
        raise ValueError("Invalid checkpoint class encoding")
    model = build_model(model_name, payload["in_channels"], classes.numel(), payload["config"]["model"])
    model.load_state_dict(payload["model_state_dict"], strict=True)
    model.to(device).eval().requires_grad_(False)
    return model, classes, payload


def evaluate_reweight(model, graphs, classes, metric, device, **options):
    rows, all_logits, all_labels = [], [], []
    # Every graph gets freshly initialized MLPs; seeds do not depend on training RNG.
    seed = options.pop("seed", 0)
    for index, original in enumerate(graphs):
        graph = original.clone().to(device)
        from torch_geometric.data import Data
        visible = Data(x=graph.x, edge_index=graph.edge_index,
                       edge_weight=getattr(graph, "edge_weight", None), num_nodes=graph.num_nodes)
        adapted, info = adapt_reweight(model, visible, seed=seed + index, **options)
        labels, mask = labels_and_mask(graph)
        with torch.no_grad():
            baseline = model(graph.x, graph.edge_index, getattr(graph, "edge_weight", None))[mask]
            logits = model(adapted.x, adapted.edge_index, adapted.edge_weight)[mask]
        y = labels[mask].cpu()
        erm = score_logits(baseline, y, classes, metric)
        score = score_logits(logits, y, classes, metric)
        rows.append({"test_graph": index, "environment": getattr(graph, "environment", None),
                     "domain": getattr(graph, "domain", None), "time_step": getattr(graph, "time_step", None),
                     "erm": erm, "reweight": score, "delta": score - erm, **info})
        all_logits.append(logits.cpu())
        all_labels.append(y)
        print(f"test[{index}] ERM={erm:.6f} reweight={score:.6f} "
              f"steps={info['steps']} updated_branches={info['updated_branches']}/4")
    scores = [r["reweight"] for r in rows]
    return {"method": "learnable_multiplicative_reweight", "faithful_tt_greb_verified": False,
            "per_graph": rows, "mean": float(np.mean(scores)), "std_across_graphs": float(np.std(scores)),
            "pooled": score_logits(torch.cat(all_logits), torch.cat(all_labels), classes, metric),
            "mean_delta": float(np.mean([r["delta"] for r in rows])),
            "applied_graphs": len(rows), "skipped_graphs": 0}
