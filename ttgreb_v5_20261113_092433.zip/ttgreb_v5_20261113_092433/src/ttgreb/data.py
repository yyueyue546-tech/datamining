"""PDF environment/time/domain splits, without new perturbations or random splits."""
from pathlib import Path
import pickle

import torch
from torch_geometric.data import Data
from torch_geometric.datasets import Amazon, Planetoid

from .models._elliptic import load_elliptic
from .twitch import load_twitch

DATASETS = ("cora", "amazon_photo", "twitch", "elliptic")
DOMAINS = ("DE", "ENGB", "ES", "FR", "PTBR", "RU", "TW")
METRICS = {"cora": "accuracy", "amazon_photo": "accuracy", "twitch": "roc_auc", "elliptic": "f1_macro"}


def generator_for(dataset, override=None):
    return override or ("gat" if dataset == "cora" else "gcn")


def synthetic_folder(root, dataset):
    return root / ("Planetoid/cora" if dataset == "cora" else "Amazon/Photo")


def required_files(root, dataset, generator=None):
    root = Path(root)
    if dataset in ("cora", "amazon_photo"):
        folder = synthetic_folder(root, dataset)
        files = [folder / f"gen/{i}-{generator_for(dataset, generator)}.pkl" for i in range(10)]
        if not (folder / "processed/data.pt").is_file():
            raw_names = ([f"ind.cora.{s}" for s in ("x", "tx", "allx", "y", "ty", "ally", "graph", "test.index")]
                         if dataset == "cora" else ["amazon_electronics_photo.npz"])
            files += [folder / "raw" / name for name in raw_names]
        return files
    if dataset == "elliptic":
        return [root / f"elliptic/{i}.pkl" for i in range(6, 49)]
    if dataset == "twitch":
        return [root / f"twitch/{domain}/musae_{domain}_{suffix}" for domain in DOMAINS
                for suffix in ("edges.csv", "target.csv", "features.json")]
    raise ValueError(dataset)


def preflight(root, dataset, generator=None):
    files = required_files(root, dataset, generator)
    missing = [str(p) for p in files if not p.is_file()]
    return {"dataset": dataset, "ready": not missing, "required_files": len(files), "missing": missing}


def load_synthetic(root, dataset, generator):
    folder = synthetic_folder(root, dataset)
    cache = folder / "processed/data.pt"
    if cache.is_file():
        # PyG caches may contain (Data, slices) or (dict, slices, DataClass).
        payload = torch.load(cache, map_location="cpu", weights_only=False)
        raw = payload[0] if isinstance(payload, (tuple, list)) else payload
        edges = raw["edge_index"]
    else:
        # Preflight guarantees raw files exist, so no dataset download is needed.
        ds = (Planetoid(str(root / "Planetoid"), name="cora") if dataset == "cora"
              else Amazon(str(root / "Amazon"), name="Photo"))
        edges = ds[0].edge_index
    graphs = []
    for index in range(10):
        with (folder / f"gen/{index}-{generator}.pkl").open("rb") as handle:
            x, y = pickle.load(handle)
        graphs.append(Data(x=torch.as_tensor(x, dtype=torch.float32),
                           y=torch.as_tensor(y, dtype=torch.long).reshape(-1),
                           edge_index=torch.as_tensor(edges, dtype=torch.long),
                           environment=index))
    return dict(train=graphs[:1], valid=graphs[1:2], test=graphs[2:])


def validate_splits(splits):
    width = None
    for split in ("train", "valid", "test"):
        if not splits.get(split):
            raise ValueError(f"Empty {split} split")
        for graph in splits[split]:
            x, ei, y = graph.x, graph.edge_index, graph.y.reshape(-1)
            if x.ndim != 2 or x.size(0) == 0 or y.numel() != x.size(0):
                raise ValueError(f"Invalid graph dimensions in {split}")
            if not torch.isfinite(x).all():
                raise ValueError(f"Nonfinite features in {split}")
            if width is None:
                width = x.size(1)
            if x.size(1) != width:
                raise ValueError("Feature dimensions differ between environments")
            if ei.dtype != torch.long or ei.ndim != 2 or ei.size(0) != 2:
                raise ValueError(f"Invalid COO edge_index in {split}")
            if ei.numel() and (ei.min() < 0 or ei.max() >= x.size(0)):
                raise ValueError(f"Edge index outside node range in {split}")
            if not (y >= 0).any():
                raise ValueError(f"No labeled nodes in {split}")


def load_data(root, dataset, generator=None):
    check = preflight(root, dataset, generator)
    if not check["ready"]:
        raise FileNotFoundError("Dataset files missing:\n" + "\n".join(check["missing"]))
    root = Path(root)
    if dataset in ("cora", "amazon_photo"):
        splits = load_synthetic(root, dataset, generator_for(dataset, generator))
    elif dataset == "elliptic":
        splits = load_elliptic(root / "elliptic")
    else:
        graphs = []
        for domain in DOMAINS:
            adjacency, y, x = load_twitch(str(root), domain)
            rows, cols = adjacency.nonzero()
            graphs.append(Data(x=torch.as_tensor(x, dtype=torch.float32),
                               y=torch.as_tensor(y, dtype=torch.long),
                               edge_index=torch.tensor([rows.tolist(), cols.tolist()], dtype=torch.long),
                               domain=domain))
        splits = dict(train=graphs[:1], valid=graphs[1:2], test=graphs[2:])
    validate_splits(splits)
    return splits


def protocol(dataset, generator=None):
    if dataset in ("cora", "amazon_photo"):
        return {"kind": "environment", "generator": generator_for(dataset, generator),
                "train": [0], "valid": [1], "test": list(range(2, 10))}
    if dataset == "twitch":
        return {"kind": "domain", "train": list(DOMAINS[:1]), "valid": list(DOMAINS[1:2]),
                "test": list(DOMAINS[2:])}
    return {"kind": "time", "train": list(range(6, 11)), "valid": list(range(11, 16)),
            "test": list(range(16, 49)), "label_encoding": "read existing pkl; no relabeling"}
