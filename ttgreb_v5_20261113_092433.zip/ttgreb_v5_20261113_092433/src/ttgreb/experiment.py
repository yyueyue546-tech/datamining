"""Command line: train, tune (validation only), and run (fixed test settings)."""
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import platform

import torch
import yaml

from .data import DATASETS, METRICS, load_data, preflight, protocol
from .engine import fit, load_checkpoint, evaluate, evaluate_reweight

PROJECT = Path(__file__).resolve().parents[2]


def save_json(path, payload):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def source_hashes():
    return {str(p.relative_to(PROJECT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((PROJECT / "src").rglob("*.py"))}


def train(dataset, model_name, data_root, backbone_config, seed, device, output, splits=None):
    output = Path(output)
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"Refusing to overwrite a run: {output}")
    config = deepcopy(yaml.safe_load(Path(backbone_config).read_text(encoding="utf-8"))[model_name])
    config["training"]["validation_metric"] = METRICS[dataset]
    splits = splits or load_data(data_root, dataset)
    model, classes, best = fit(splits, model_name, config, seed, device, config["training"]["max_epochs"])
    output.mkdir(parents=True, exist_ok=True)
    payload = {"format": "ttgreb-standalone-v1", "dataset": dataset, "model": model_name,
               "config": config, "seed": seed, "in_channels": splits["train"][0].num_features,
               "classes": classes.tolist(), "epochs": config["training"]["max_epochs"],
               "protocol": protocol(dataset), "metric": METRICS[dataset],
               "data_root": str(Path(data_root).resolve()), "config_source": str(Path(backbone_config).resolve()),
               "source_hashes": source_hashes(), **best}
    checkpoint = output / "checkpoint.pt"
    torch.save(payload, checkpoint)
    save_json(output / "training.json", {k: v for k, v in payload.items() if k != "model_state_dict"})
    return model, classes, payload, checkpoint


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("command", choices=("check-data", "train", "tune", "run"))
    ap.add_argument("--dataset", choices=DATASETS, default="cora")
    ap.add_argument("--model", choices=("gcn", "graphsage"), default="gcn")
    ap.add_argument("--data-root", type=Path, required=True)
    ap.add_argument("--backbone-config", type=Path)
    ap.add_argument("--adapter-config", type=Path)
    ap.add_argument("--checkpoint", type=Path)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--threads", type=int, default=2)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--search-stage", default="screen")
    args = ap.parse_args(argv)
    if args.threads < 1:
        ap.error("threads must be positive")
    torch.set_num_threads(args.threads)
    if args.command == "check-data":
        result = preflight(args.data_root, args.dataset)
        save_json(args.output / "data_check.json", result)
        print(json.dumps(result, ensure_ascii=False))
        return 0 if result["ready"] else 2
    if args.command == "tune":
        if args.checkpoint is None:
            ap.error("tune requires --checkpoint")
        from .search import search
        search(args)
        return 0
    device = torch.device(args.device)
    splits = load_data(args.data_root, args.dataset)
    config_path = args.backbone_config or PROJECT / "configs/backbones" / f"{args.dataset}.yaml"
    if args.command == "train":
        _, _, payload, checkpoint = train(args.dataset, args.model, args.data_root, config_path,
                                         args.seed, device, args.output, splits)
        print(f"checkpoint={checkpoint} best_epoch={payload['best_epoch']} val={payload['validation']['mean']:.6f}")
        return 0
    if args.output.exists() and any(args.output.iterdir()):
        ap.error("output directory must be new or empty")
    if args.adapter_config is None:
        ap.error("run requires an explicit --adapter-config selected on validation")
    selected_text = args.adapter_config.read_text(encoding="utf-8")
    selected = yaml.safe_load(selected_text)
    if selected.get("dataset") != args.dataset or selected.get("model") != args.model:
        ap.error("adapter YAML dataset/model mismatch")
    options = dict(selected["adapter"])
    options["seed"] = args.seed
    if args.checkpoint:
        model, classes, payload = load_checkpoint(args.checkpoint, device, args.dataset, args.model)
        checkpoint = args.checkpoint.resolve()
    else:
        model, classes, payload, checkpoint = train(args.dataset, args.model, args.data_root,
                                                  config_path, args.seed, device, args.output / "training", splits)
    if payload.get("protocol") != protocol(args.dataset):
        raise ValueError("checkpoint split protocol mismatch")
    before = {k: v.clone() for k, v in model.state_dict().items()}
    baseline = evaluate(model, splits["test"], classes, METRICS[args.dataset], device)
    adapted = evaluate_reweight(model, splits["test"], classes, METRICS[args.dataset], device, **options)
    unchanged = all(torch.equal(before[k], v) for k, v in model.state_dict().items())
    if not unchanged:
        raise RuntimeError("Backbone changed during adaptation")
    result = {"dataset": args.dataset, "model": args.model, "seed": payload["seed"],
              "adapter_seed": args.seed, "metric": METRICS[args.dataset], "protocol": protocol(args.dataset),
              "checkpoint": str(Path(checkpoint).resolve()), "checkpoint_sha256": hashlib.sha256(Path(checkpoint).read_bytes()).hexdigest(),
              "adapter_yaml": str(args.adapter_config.resolve()),
              "adapter_yaml_sha256": hashlib.sha256(selected_text.encode()).hexdigest(),
              "adapter_selection": selected.get("selection"), "adapter": options,
              "best_epoch": payload["best_epoch"], "training_validation": payload["validation"],
              "erm": baseline, "ttgreb": adapted, "backbone_unchanged": unchanged,
              "test_labels_used_for_adaptation": False, "source_hashes": source_hashes(),
              "runtime": {"torch": str(torch.__version__), "python": platform.python_version(),
                          "device": str(device), "threads": torch.get_num_threads()}}
    save_json(args.output / "summary.json", result)
    print(f"ERM={baseline['mean']:.6f} TTGREB={adapted['mean']:.6f} delta_pp={100*adapted['mean_delta']:.4f}")
    return 0
