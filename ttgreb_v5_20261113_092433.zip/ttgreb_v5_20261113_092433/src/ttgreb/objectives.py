"""TT-GREB objectives transcribed from the local ICLR 2025 review PDF, p.7.

Eq.7: minimize the prototype objective. Eq.8: maximize the environment
objective. Sums and the absolute retained/complement ratio follow the printed
equations. These have not been verified against the closed ICDM final text.
"""
import torch
from torch.nn import functional as F


REFERENCE = {
    "version": "ICLR_2025_anonymous_review",
    "review_pdf_sha256": "fb5f5a7f5e24ae696ae8655073fb464dd463e1a2e455d270af013726e4582660",
    "reference_artifact_in_development_workspace": "research_notes/ttgreb_reference/reference_review.pdf",
    "equations": [5, 6, 7, 8],
    "objective_page": 7,
    "reference_artifacts_required_for_execution": False,
    "published_doi": "10.1109/ICDM65498.2025.00105",
    "published_full_text_verified": False,
}


def ratio_regularizer(weight, target, eps=1e-8):
    """Printed Reg(W)=abs(sum(W)/sum(1-W) - lambda), not mean(W) MSE.

    Empty edge sets contribute zero; clamp only the denominator to avoid 0/0
    or division by zero for a fully saturated sigmoid.
    """
    if not weight.numel():
        return weight.sum()
    return (weight.sum() / (1 - weight).sum().clamp_min(eps) - target).abs()


def prototype_objective(reborn, prototype, environment, node_weight, edge_weight,
                        *, alpha, node_target, edge_target):
    positive = (1 - F.cosine_similarity(reborn, prototype, dim=-1, eps=1e-8)).sum()
    negative = (1 - F.cosine_similarity(environment, prototype, dim=-1, eps=1e-8)).sum()
    regularizer = (ratio_regularizer(node_weight, node_target)
                   + ratio_regularizer(edge_weight, edge_target))
    loss = positive - negative + alpha * regularizer
    return loss, {"positive_distance": positive, "negative_distance": negative,
                  "regularizer": regularizer}


def environment_objective(original, environment, node_weight, edge_weight,
                          *, beta, node_target, edge_target):
    distance = (original - environment).square().sum()
    regularizer = (ratio_regularizer(node_weight, node_target)
                   + ratio_regularizer(edge_weight, edge_target))
    objective = distance - beta * regularizer
    return objective, {"distance_squared": distance, "regularizer": regularizer}
