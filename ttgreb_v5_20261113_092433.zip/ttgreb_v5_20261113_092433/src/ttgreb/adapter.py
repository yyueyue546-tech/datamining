"""Multiplicative reweighting with alternating TT-GREB review-paper objectives.

The equations follow the locally reviewed anonymous ICLR manuscript.
Initialization and optimizer settings are explicit experimental choices.
"""
import math
import time

import torch
from torch import nn
from torch.nn import functional as F
from torch_geometric.data import Data

from .objectives import REFERENCE, prototype_objective, environment_objective


class _ReweightMLP(nn.Module):
    def __init__(self, in_dim, out_dim, hidden_dim=None):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(in_dim, hidden_dim or in_dim), nn.ReLU(),
                                 nn.Linear(hidden_dim or in_dim, out_dim))

    def forward(self, x):
        return self.net(x).sigmoid()

    def edges(self, x, edge_index):
        # Exactly Linear(cat(x[src], x[dst])), without an [E, 2D] allocation.
        first, _, last = self.net
        d = x.size(1)
        source = F.linear(x, first.weight[:, :d], first.bias)
        target = F.linear(x, first.weight[:, d:])
        src, dst = edge_index
        return last((source[src] + target[dst]).relu()).sigmoid().squeeze(-1)


class TTGREBAdapter(nn.Module):
    def __init__(self, feature_dim, hidden_dim=None, init_probability=None, init_gain=.1, mode="both"):
        if mode not in ("both", "features", "edges"):
            raise ValueError(mode)
        super().__init__()
        self.mode = mode
        self.prototype_node = _ReweightMLP(feature_dim, feature_dim, hidden_dim)
        self.environment_node = _ReweightMLP(feature_dim, feature_dim, hidden_dim)
        self.prototype_edge = _ReweightMLP(2 * feature_dim, 1, hidden_dim)
        self.environment_edge = _ReweightMLP(2 * feature_dim, 1, hidden_dim)
        if init_probability is not None:
            if not 0 < init_probability < 1:
                raise ValueError("init_probability must be strictly between 0 and 1")
            # A warm start for multiplicative weights. Keep nonzero last-layer
            # weights so all four MLPs receive first-layer gradients immediately.
            with torch.no_grad():
                for branch in self.children():
                    branch.net[-1].weight.mul_(init_gain)
                    branch.net[-1].bias.fill_(math.log(init_probability / (1 - init_probability)))

    def weights(self, x, edge_index):
        pn, en = self.prototype_node(x), self.environment_node(x)
        pe, ee = self.prototype_edge.edges(x, edge_index), self.environment_edge.edges(x, edge_index)
        if self.mode == "edges": pn, en = torch.ones_like(pn), torch.ones_like(en)
        if self.mode == "features": pe, ee = torch.ones_like(pe), torch.ones_like(ee)
        return pn, en, pe, ee

    def set_phase(self, phase):
        if phase not in ("prototype", "environment"):
            raise ValueError(phase)
        self.zero_grad(set_to_none=True)
        for name, branch in self.named_children():
            branch.requires_grad_(name.startswith(phase + "_"))

    def phase_parameters(self, phase):
        return [p for name, branch in self.named_children() if name.startswith(phase + "_")
                for p in branch.parameters()]

    @staticmethod
    def compose(x, base_edge_weight, weights):
        p_node, e_node, p_edge, e_edge = weights
        node_weight = p_node + (1 - p_node) * e_node
        edge_weight = p_edge + (1 - p_edge) * e_edge
        return x * node_weight, base_edge_weight * edge_weight


def _numbers(terms):
    return {key: float(value.detach()) for key, value in terms.items()}


def adapt_reweight(model, graph, *, steps=20, lr=1e-2, alpha=.1, beta=.1,
                   prototype_ratio=.5, environment_ratio=.5, prototype_edge_ratio=None,
                   environment_edge_ratio=None, seed=0, hidden_dim=None,
                   init_probability=None, observer=None, observe_steps=None, init_gain=.1, mode="both"):
    """Each call starts a new adapter. Only x and edges enter optimization.

    GNN parameters/buffers stay frozen, but autograd through its operations
    stays enabled so losses can update the four MLPs.
    """
    if steps < 1 or not math.isfinite(lr) or lr <= 0:
        raise ValueError("steps >= 1 and finite lr > 0 are required")
    if not all(math.isfinite(v) and v >= 0 for v in (alpha, beta)):
        raise ValueError("alpha and beta must be finite and nonnegative")
    prototype_edge_ratio = prototype_ratio if prototype_edge_ratio is None else prototype_edge_ratio
    environment_edge_ratio = environment_ratio if environment_edge_ratio is None else environment_edge_ratio
    if not all(math.isfinite(v) and v >= 0 for v in (prototype_ratio, environment_ratio,
                                                   prototype_edge_ratio, environment_edge_ratio)):
        raise ValueError("retained/complement ratio targets must be finite and nonnegative")
    if hidden_dim is not None and hidden_dim < 1:
        raise ValueError("hidden_dim must be positive")
    if not graph.x.numel() or not torch.isfinite(graph.x).all():
        raise ValueError("features must be nonempty and finite")
    if len(model.convs) < 2:
        raise ValueError("This embedding objective requires at least two backbone layers")
    start = time.perf_counter()
    x, ei = graph.x.detach(), graph.edge_index.detach()
    base = getattr(graph, "edge_weight", None)
    base = x.new_ones(ei.size(1)) if base is None else base.detach()
    if base.shape != (ei.size(1),) or not torch.isfinite(base).all() or (base < 0).any():
        raise ValueError("base edge weights must be finite, nonnegative, and one per edge")
    model.eval().requires_grad_(False)
    model.zero_grad(set_to_none=True)
    # fork_rng makes initialization independent of training/checkpoint loading.
    devices = [x.device.index] if x.is_cuda else []
    with torch.random.fork_rng(devices=devices):
        torch.manual_seed(seed)
        adapter = TTGREBAdapter(x.size(1), hidden_dim, init_probability, init_gain, mode).to(device=x.device, dtype=x.dtype)
    initial = {k: v.detach().clone() for k, v in adapter.named_parameters()}
    optimizers = {phase: torch.optim.Adam(adapter.phase_parameters(phase), lr=lr)
                  for phase in ("prototype", "environment")}
    with torch.no_grad():
        original_embedding = model.get_embeddings(x, ei, base).detach()

    def pro_objective():
        weights = adapter.weights(x, ei)
        p_node, e_node, p_edge, e_edge = weights
        x_new, edge_new = adapter.compose(x, base, weights)
        combined = model.get_embeddings(x_new, ei, edge_new)
        # Eq.5: the prototype view must use BOTH prototype node and edge weights.
        prototype = model.get_embeddings(x * p_node, ei, base * p_edge)
        environment = model.get_embeddings(x * e_node, ei, base * e_edge)
        return prototype_objective(combined, prototype, environment,
                                   p_node if mode != "edges" else p_node.new_empty(0),
                                   p_edge if mode != "features" else p_edge.new_empty(0),
                                   alpha=alpha, node_target=prototype_ratio,
                                   edge_target=prototype_edge_ratio)

    def env_objective():
        e_node = adapter.environment_node(x) if mode != "edges" else torch.ones_like(x)
        e_edge = adapter.environment_edge.edges(x, ei) if mode != "features" else torch.ones_like(base)
        environment = model.get_embeddings(x * e_node, ei, base * e_edge)
        return environment_objective(original_embedding, environment,
                                     e_node if mode != "edges" else e_node.new_empty(0),
                                     e_edge if mode != "features" else e_edge.new_empty(0),
                                     beta=beta, node_target=environment_ratio,
                                     edge_target=environment_edge_ratio)

    @torch.no_grad()
    def observe(step):
        if observer is None or (observe_steps is not None and step not in observe_steps):
            return
        ws = adapter.weights(x, ei)
        features, edges = adapter.compose(x, base, ws)
        statistics = {}
        for name, weight in zip(("prototype_node", "environment_node", "prototype_edge", "environment_edge"), ws):
            statistics[name] = {"mean": float(weight.mean()) if weight.numel() else None,
                                "low_fraction": float((weight < .01).float().mean()) if weight.numel() else None,
                                "high_fraction": float((weight > .99).float().mean()) if weight.numel() else None}
        statistics["composed"] = {"feature_mean": float((ws[0]+(1-ws[0])*ws[1]).mean()),
                                  "feature_std": float((ws[0]+(1-ws[0])*ws[1]).std(unbiased=False)),
                                  "edge_mean": float((ws[2]+(1-ws[2])*ws[3]).mean()),
                                  "edge_std": float((ws[2]+(1-ws[2])*ws[3]).std(unbiased=False))}
        visible = Data(x=features.detach(), edge_index=ei, edge_weight=edges.detach(), num_nodes=x.size(0))
        observer(step, visible, statistics)

    history = []
    gradient_norms = {name: 0. for name, _ in adapter.named_children()}

    def update(loss, phase, step):
        if not torch.isfinite(loss):
            raise RuntimeError(f"Nonfinite {phase} objective at round {step}")
        loss.backward()
        for name, branch in adapter.named_children():
            square_norm = 0.
            for parameter in branch.parameters():
                if parameter.grad is not None:
                    if not name.startswith(phase + "_"):
                        raise RuntimeError(f"Inactive branch received gradient: {name}")
                    if not torch.isfinite(parameter.grad).all():
                        raise RuntimeError(f"Nonfinite adapter gradient: {name}")
                    square_norm += float(parameter.grad.double().square().sum())
            gradient_norms[name] = max(gradient_norms[name], math.sqrt(square_norm))
        optimizers[phase].step()

    with torch.no_grad():
        initial_pro, _ = pro_objective()
        initial_env, _ = env_objective()
    observe(0)
    # Deliberately re-enable input gradients even if called inside no_grad.
    with torch.enable_grad():
        for step in range(1, steps + 1):
            adapter.set_phase("prototype")
            loss_pro, pro_parts = pro_objective()
            update(loss_pro, "prototype", step)
            # A fresh forward pass follows the completed prototype update.
            adapter.set_phase("environment")
            objective_env, env_parts = env_objective()
            # Eq.8 is a maximization: Adam minimizes its NEGATIVE.
            update(-objective_env, "environment", step)
            history.append({"round": step, "prototype_descent_loss": float(loss_pro.detach()),
                            "environment_ascent_objective": float(objective_env.detach()),
                            "environment_descent_loss": float(-objective_env.detach()),
                            "prototype_terms": _numbers(pro_parts), "environment_terms": _numbers(env_parts)})
            observe(step)
    with torch.no_grad():
        final_pro, final_pro_parts = pro_objective()
        final_env, final_env_parts = env_objective()
        weights = adapter.weights(x, ei)
        adapted_x, adapted_edges = adapter.compose(x, base, weights)
        if not all(torch.isfinite(t).all() for t in (final_pro, final_env, adapted_x, adapted_edges)):
            raise RuntimeError("Nonfinite adapted graph or final loss")
        changes = {name: max(float((parameter - initial[f"{name}.{key}"]).abs().max())
                             for key, parameter in branch.named_parameters())
                   for name, branch in adapter.named_children()}
    # Never carry labels/masks into the adapted result or any loss computation.
    result = Data(x=adapted_x.detach(), edge_index=ei.clone(), edge_weight=adapted_edges.detach(),
                  num_nodes=x.size(0))
    info = {"mode": mode, "init_gain": init_gain, "status": "applied", "reason": None, "steps": steps, "seed": seed,
            "objective_version": "ttgreb_review_eq7_eq8_v2", "objective_reference": REFERENCE,
            "objective_equations_verified": True, "loss_reduction": "sum",
            "optimization": "alternating_prototype_descent_environment_ascent",
            "optimizer_steps": {"prototype": steps, "environment": steps},
            "trainable_adapter_parameters": sum(p.numel() for p in adapter.parameters()),
            "branch_max_parameter_change": changes, "branch_max_gradient_norm": gradient_norms,
            "updated_branches": sum(v > 0 for v in changes.values()),
            "initial_prototype_loss": float(initial_pro), "final_prototype_loss": float(final_pro),
            "initial_environment_objective": float(initial_env), "final_environment_objective": float(final_env),
            "final_prototype_terms": _numbers(final_pro_parts),
            "final_environment_terms": _numbers(final_env_parts), "loss_history": history,
            "changed_feature_entries": int((adapted_x != x).sum()),
            "changed_edge_weights": int((adapted_edges != base).sum()),
            "seconds": time.perf_counter() - start}
    return result, info
