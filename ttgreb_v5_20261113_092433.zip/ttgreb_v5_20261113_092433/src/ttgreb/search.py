"""Search only validation environment(s), keeping every candidate and failure."""
from itertools import product
import hashlib
import json
from pathlib import Path
import time

import torch
import yaml

from .adapter import adapt_reweight
from .data import load_data, METRICS
from .engine import load_checkpoint, labels_and_mask, score_logits, evaluate
from .experiment import save_json, source_hashes
from torch_geometric.data import Data

STOPS = (1, 2, 3, 5, 10, 20)


def candidates(stage):
    base = dict(steps=20, lr=.0001, alpha=.1, beta=.1,
                prototype_ratio=.5, environment_ratio=.5,
                hidden_dim=64, init_probability=None)
    if stage == "screen":
        grid = product((1e-5, 1e-4, 1e-3, .003), (.1, 300.), (.1, 10000.), (None, .9))
        for lr, alpha, beta, probability in grid:
            yield {**base, "lr": lr, "alpha": alpha, "beta": beta,
                   "init_probability": probability,
                   "prototype_ratio": .5 if probability is None else 9.,
                   "environment_ratio": .5 if probability is None else 9.}
    elif stage == "refine":
        grid = product((3e-6, 3e-5, 3e-4), (None, .7, .9, .99), (.1, 30., 300.))
        for lr, probability, regularizer in grid:
            ratio = .5 if probability is None else probability / (1 - probability)
            yield {**base, "lr": lr, "alpha": regularizer, "beta": regularizer * 32,
                   "init_probability": probability, "prototype_ratio": ratio, "environment_ratio": ratio}
    elif stage == "legacy_width":
        for lr, probability in product((1e-6, 1e-5, 1e-4), (None, .9)):
            yield {**base, "lr": lr, "hidden_dim": None, "init_probability": probability,
                   "prototype_ratio": .5 if probability is None else 9.,
                   "environment_ratio": .5 if probability is None else 9.}
    elif stage == "long":
        for lr, probability, alpha, beta in product((.0003, .001, .003), (.9, .99), (.1, 300.), (.1, 10000.)):
            ratio = probability / (1 - probability)
            yield {**base, "steps": 100, "lr": lr, "alpha": alpha, "beta": beta,
                   "init_probability": probability, "prototype_ratio": ratio, "environment_ratio": ratio}
    else:
        # An explicit YAML shortlist enables cross-seed validation without test access.
        payload = yaml.safe_load(Path(stage).read_text(encoding="utf-8"))
        for item in payload["candidates"]:
            yield item


def validation_trajectory(model, graph, classes, metric, options, seed, stops=STOPS):
    labels, mask = labels_and_mask(graph)
    trajectory = []

    @torch.no_grad()
    def observer(step, visible, stats):
        logits = model(visible.x, visible.edge_index, visible.edge_weight)[mask]
        trajectory.append({"round": step, "score": score_logits(logits, labels[mask], classes, metric),
                           "weights": stats})

    visible = Data(x=graph.x, edge_index=graph.edge_index,
                   edge_weight=getattr(graph, "edge_weight", None), num_nodes=graph.num_nodes)
    adapted, info = adapt_reweight(model, visible, seed=seed, observer=observer,
                                  observe_steps={0, *stops}, **options)
    del adapted
    return trajectory, info


def search(args):
    output = args.output
    output.mkdir(parents=True, exist_ok=True)
    trial_path = output / "trials.jsonl"
    model, classes, payload = load_checkpoint(args.checkpoint, torch.device(args.device), args.dataset, args.model)
    # The search never calls evaluate on splits['test'].
    splits = load_data(args.data_root, args.dataset)
    validation = [g.to(args.device) for g in splits["valid"]]
    metric = METRICS[args.dataset]
    baseline = evaluate(model, validation, classes, metric, torch.device(args.device))["mean"]
    identity = {"checkpoint_sha256": hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
                "stage": args.search_stage, "dataset": args.dataset, "model": args.model,
                "seed": args.seed, "split": "valid", "environment": [getattr(g, "environment", None) for g in validation],
                "test_evaluated": False, "baseline_validation": baseline}
    metadata_path = output / "search.json"
    if metadata_path.exists():
        previous = json.loads(metadata_path.read_text(encoding="utf-8"))
        if previous["identity"] != identity:
            raise ValueError("Search resume identity mismatch")
    save_json(metadata_path, {"identity": identity})
    trials = [json.loads(line) for line in trial_path.read_text(encoding="utf-8").splitlines()] if trial_path.exists() else []
    done = {r["id"] for r in trials}
    for i, options in enumerate(candidates(args.search_stage)):
        trial_id = hashlib.sha256(json.dumps(options, sort_keys=True).encode()).hexdigest()[:12]
        if trial_id in done:
            continue
        start = time.perf_counter()
        try:
            stops = tuple(sorted({s for s in (*STOPS, 30, 50, 75, 100) if s <= options["steps"]}))
            graphs = [validation_trajectory(model, graph, classes, metric, options, args.seed + j,
                                            stops=stops)
                      for j, graph in enumerate(validation)]
            points = []
            for step in stops:
                matches = [next((r for r in trajectory if r["round"] == step), None) for trajectory, _ in graphs]
                if all(matches):
                    points.append({"round": step, "score": sum(r["score"] for r in matches) / len(matches)})
            best = max(points, key=lambda r: (r["score"], -r["round"]))
            row = {"id": trial_id, "options": options, "best": best, "points": points,
                   "trajectories": [t for t, _ in graphs], "adaptation": [info for _, info in graphs],
                   "status": "ok", "seconds": time.perf_counter() - start}
        except (RuntimeError, ValueError) as exc:
            row = {"id": trial_id, "options": options, "status": "failed", "error": str(exc),
                   "seconds": time.perf_counter() - start}
        with trial_path.open("a", encoding="utf-8") as handle:
            row["source_hashes"] = source_hashes()
            handle.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
        trials.append(row)
        ranked = sorted((r for r in trials if r["status"] == "ok"),
                        key=lambda r: (-r["best"]["score"], r["best"]["round"], r["id"]))
        save_json(metadata_path, {"identity": identity, "completed": len(trials),
                  "ranking": [{"id": r["id"], "options": r["options"], "best": r["best"]} for r in ranked]})
        print(f"candidate={i+1} id={trial_id} {row['status']} "
              f"best={row.get('best')} baseline={baseline:.6f} seconds={row['seconds']:.1f}", flush=True)
    print(f"Saved validation-only search: {metadata_path}", flush=True)
