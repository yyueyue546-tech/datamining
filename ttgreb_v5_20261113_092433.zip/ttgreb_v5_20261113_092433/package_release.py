"""Build a clean code/results archive, preserving the full local study."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import zipfile
import datetime

ROOT=Path(__file__).resolve().parent


def export(target):
    target=target.resolve()
    if target.exists():raise FileExistsError(f'Refusing to overwrite export: {target}')
    target.mkdir(parents=True)
    for name in ('src','configs','tests','reports'):
        shutil.copytree(ROOT/name,target/name,ignore=shutil.ignore_patterns('__pycache__','pause_status.json'))
    for path in ROOT.glob('*.py'):shutil.copy2(path,target/path.name)
    for name in ('README.md','RESULTS.md','requirements.txt','.gitignore'):
        shutil.copy2(ROOT/name,target/name)
    hashes={str(p.relative_to(target)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(target.rglob('*')) if p.is_file()}
    (target/'EXPORT_MANIFEST.json').write_text(json.dumps(hashes,indent=2),encoding='utf8')
    return target,hashes


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=ROOT.parent/'deliverables');p.add_argument('--smoke',action='store_true')
    args=p.parse_args();stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    target=args.output/f'ttgreb_v5_{stamp}'
    if not args.smoke:
        complete=json.loads((ROOT/'reports/completion.json').read_text(encoding='utf8'))
        audit=json.loads((ROOT/'reports/final_audit.json').read_text(encoding='utf8'))
        if not complete['all_completed'] or not audit['passed']:raise RuntimeError('Study incomplete or audit failed')
    folder,hashes=export(target)
    if not args.smoke:
        archive=target.with_suffix('.zip')
        with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
            for f in sorted(target.rglob('*')):
                if f.is_file():z.write(f,Path(target.name)/f.relative_to(target))
        print(json.dumps(dict(folder=str(folder),archive=str(archive),files=len(hashes),sha256=hashlib.sha256(archive.read_bytes()).hexdigest())))
    else:print(str(folder))


if __name__=='__main__':main()
