"""Standalone additive reproduction study. Selection uses validation only."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
WORKSPACE = PROJECT.parent
sys.path.insert(0, str(ROOT / 'src'))
if (WORKSPACE / '.codex_deps').is_dir():
    sys.path.insert(0, str(WORKSPACE / '.codex_deps'))

import argparse
from copy import deepcopy
import gc
import hashlib
import json
import time
import statistics
import random
import numpy as np
import torch
from torch.nn import functional as F
from torch_geometric.data import Data
from torch_geometric.utils import to_undirected
import yaml
from sklearn.metrics import confusion_matrix
from ttgreb.data import load_data, METRICS, protocol
from ttgreb.engine import labels_and_mask, seed_everything, load_checkpoint, score_logits
from ttgreb.models import build_model
from ttgreb.adapter import TTGREBAdapter, adapt_reweight
from metrics_audit import historical_audit, aggregations

torch.set_num_threads(1)
ART = ROOT / 'artifacts'
ALL_DATASETS = ('cora', 'amazon_photo', 'elliptic', 'twitch')
MODELS = ('gcn', 'graphsage')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()


def identity(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True).encode()).hexdigest()[:16]


def save(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    obj = json.loads(json.dumps(obj, allow_nan=False))
    if path.exists():
        if read(path) != obj: raise FileExistsError(f'Immutable artifact exists: {path}')
        return
    tmp = path.with_suffix(path.suffix + '.writing')
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf8')
    tmp.replace(path)


def log(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf8') as f: f.write(json.dumps(obj, allow_nan=False) + '\n')


def prepare(raw, opts):
    result = {}
    for split, graphs in raw.items():
        result[split] = []
        for g in graphs:
            new = g.clone()
            if opts.get('undirected'): new.edge_index = to_undirected(new.edge_index, num_nodes=new.num_nodes)
            if opts.get('feature_norm', 'none') == 'node_l2': new.x = F.normalize(new.x, p=2, dim=1)
            result[split].append(new)
    return result


def seed_choice(dataset, model):
    portable = ROOT / f'configs/starting/{dataset}_{model}.json'
    if portable.exists(): return read(portable)
    if dataset in ('cora', 'amazon_photo'):
        choice = read(PROJECT / f'experiments/capacity_v3/artifacts/{dataset}/{model}/locked.json')['primary']
    else:
        choice = read(PROJECT / f'experiments/elliptic_twitch_v4/artifacts/{dataset}/{model}/test/primary/seed0/summary.json')['choice']
    return {k: choice[k] for k in ('label', 'config', 'options')}


def snapshot():
    if not (PROJECT/'experiments/elliptic_twitch_v4').is_dir():
        return 0
    path = ART / 'preservation_manifest.json'
    if not path.exists():
        files = []
        for name in ('src', 'configs', 'tests', 'scripts', 'runs', 'results', 'experiments'):
            for p in (PROJECT / name).rglob('*'):
                if any(s.startswith(('tmp', '__pycache__')) for s in p.relative_to(PROJECT).parts): continue
                if p.is_file(): files.append(p)
        files += [PROJECT / n for n in ('README.md', 'run.py', 'pyproject.toml', 'requirements.txt', '.gitignore') if (PROJECT/n).is_file()]
        save(path, {str(p.relative_to(PROJECT)): digest(p) for p in sorted(set(files))})
    expected = read(path)
    bad = [p for p, sha in expected.items() if not (PROJECT / p).is_file() or digest(PROJECT / p) != sha]
    if bad: raise RuntimeError(f'Historical artifacts changed: {bad}')
    return len(expected)


def canonical_config(c):
    c = deepcopy(c)
    c.setdefault('preprocessing', {}).setdefault('undirected', False)
    c['preprocessing'].setdefault('feature_norm', 'none')
    c['training'].setdefault('class_balance', 'none')
    c['training'].setdefault('minimum_epochs', 50)
    c['training'].setdefault('patience', 50)
    return c


def training_key(dataset, model, config, seed, selection):
    return identity(dict(dataset=dataset, model=model, config=canonical_config(config), seed=seed, selection=selection))


def build_registry():
    """Only complete training metadata; never reuse on superficial architecture similarity."""
    entries = []
    for p in (PROJECT / 'experiments').glob('*/artifacts/**/training.json'):
        if any(s.startswith('tmp') for s in p.parts): continue
        row = read(p)
        c = row.get('study_config', row.get('config'))
        if not c or not row.get('checkpoint'): continue
        if not Path(row['checkpoint']).is_file(): continue
        entries.append(dict(dataset=row['dataset'], model=row['model'], config=c, seed=row['seed'],
                            checkpoint=row['checkpoint'], source=str(p), selection='time_mean'))
    for p in (PROJECT / 'runs').glob('*/*/train_seed*/checkpoint.pt'):
        payload = torch.load(p, map_location='cpu', weights_only=False)
        entries.append(dict(dataset=payload['dataset'], model=payload['model'], config=payload['config'],
            seed=payload['seed'], checkpoint=str(p), source=str(p), selection='time_mean'))
    index = {}
    for row in entries:
        if row.get('source','').endswith('checkpoint.pt') or '/training/reference/' in row.get('source','').replace('\\','/'):
            row['config'] = deepcopy(row['config'])
            row['config']['training'].setdefault('minimum_epochs', row['config']['training']['max_epochs'])
            row['config']['training'].setdefault('patience', row['config']['training']['max_epochs'])
        key = training_key(row['dataset'], row['model'], row['config'], row['seed'], row['selection'])
        index.setdefault(key, row)
    save(ART / 'historical_training_registry_v2.json', index)
    return index


@torch.no_grad()
def evaluate(model, graphs, classes, dataset):
    logits, labels, per = [], [], []
    for g in graphs:
        y, mask = labels_and_mask(g)
        out = model(g.x, g.edge_index, getattr(g, 'edge_weight', None))[mask]
        logits.append(out); labels.append(y[mask])
        per.append(score_logits(out, y[mask], classes, METRICS[dataset]))
    return dict(mean=statistics.mean(per), per_graph=per,
        pooled=score_logits(torch.cat(logits), torch.cat(labels), classes, METRICS[dataset]))


def train(dataset, model_name, config, seed, raw, selection='time_mean'):
    key = training_key(dataset, model_name, config, seed, selection)
    folder = ART / 'training' / dataset / model_name / key
    path = folder / 'training.json'
    if path.exists():
        row = read(path)
        if digest(row['checkpoint']) != row['checkpoint_sha256']: raise ValueError('Checkpoint changed')
        return row
    registry = read(ART / 'historical_training_registry_v2.json') if (ART / 'historical_training_registry_v2.json').exists() else {}
    if key in registry:
        old = registry[key]
        row = dict(**old, key=key, checkpoint_sha256=digest(old['checkpoint']), reused=True)
        save(path, row); print(f'REUSE {dataset}/{model_name}/s{seed}', flush=True); return row
    seed_everything(seed)
    splits = prepare(raw, config.get('preprocessing', {}))
    classes = torch.cat([g.y[labels_and_mask(g)[1]] for g in splits['train']]).unique()
    model = build_model(model_name, splits['train'][0].num_features, len(classes), config['model'])
    opts = config['training']
    optimizer = {'Adam':torch.optim.Adam, 'AdamW':torch.optim.AdamW}[opts['optimizer']](
        model.parameters(), lr=opts['learning_rate'], weight_decay=opts['weight_decay'])
    class_weights = None
    if opts.get('class_balance') == 'sqrt_inverse':
        ys = torch.cat([g.y[labels_and_mask(g)[1]] for g in splits['train']])
        counts = torch.stack([(ys == c).sum() for c in classes]).float()
        class_weights = (counts.sum() / (len(classes) * counts)).sqrt(); class_weights /= class_weights.mean()
    best, stale = None, 0
    start = time.perf_counter()
    folder.mkdir(parents=True, exist_ok=True)
    for epoch in range(1, opts['max_epochs'] + 1):
        model.train()
        for g in splits['train']:
            y, mask = labels_and_mask(g); target = torch.searchsorted(classes, y[mask])
            optimizer.zero_grad(set_to_none=True)
            logits = model(g.x, g.edge_index)[mask]
            if opts['loss'] == 'cross_entropy': loss = F.cross_entropy(logits, target, weight=class_weights)
            else:
                values = F.binary_cross_entropy_with_logits(logits, F.one_hot(target, len(classes)).to(logits), reduction='none').mean(-1)
                loss = values.mean() if class_weights is None else (values * class_weights[target]).sum() / class_weights[target].sum()
            if not torch.isfinite(loss): raise RuntimeError('Nonfinite training loss')
            loss.backward(); optimizer.step()
        model.eval()
        val = evaluate(model, splits['valid'], classes, dataset)
        metric = val['pooled'] if selection == 'pooled' else val['mean']
        if best is None or metric > best['selection_score']:
            best = dict(best_epoch=epoch, validation=val, selection_score=metric,
                        model_state_dict={k:v.detach().clone() for k,v in model.state_dict().items()}); stale = 0
        else: stale += 1
        log(folder / 'history.jsonl', dict(epoch=epoch, validation=metric, best=best['selection_score']))
        if epoch >= opts.get('minimum_epochs', 50) and stale >= opts.get('patience', 50):
            break
    checkpoint = folder / 'checkpoint.pt'
    if checkpoint.exists(): checkpoint = folder / f'checkpoint_retry{time.time_ns()}.pt'
    torch.save(dict(dataset=dataset, model=model_name, config=config, seed=seed,
        in_channels=splits['train'][0].num_features, classes=classes.tolist(), selection=selection,
        **best), checkpoint)
    row = dict(dataset=dataset, model=model_name, config=config, seed=seed, key=key, selection=selection,
        checkpoint=str(checkpoint), checkpoint_sha256=digest(checkpoint), reused=False,
        validation=best['validation'], best_epoch=best['best_epoch'], epochs=epoch, seconds=time.perf_counter()-start)
    save(path, row)
    print(f'TRAIN {dataset}/{model_name}/s{seed} val={best["selection_score"]:.5f} sec={row["seconds"]:.1f}', flush=True)
    del model, optimizer; gc.collect()
    return row


def predict_graph(model, g, classes):
    y, mask = labels_and_mask(g)
    with torch.no_grad(): logits = model(g.x, g.edge_index, getattr(g, 'edge_weight', None))[mask].cpu()
    return logits, y[mask].cpu(), classes[logits.argmax(-1)]


def adapt_points(model, g, classes, dataset, options, seed, stops):
    points, arrays = {}, {}
    # Neither labels nor masks enter the adapter.
    visible = Data(x=g.x, edge_index=g.edge_index, edge_weight=getattr(g, 'edge_weight', None), num_nodes=g.num_nodes)
    def observer(step, adapted, stats):
        if step not in stops: return
        y, mask = labels_and_mask(g)
        with torch.no_grad(): out = model(adapted.x, adapted.edge_index, adapted.edge_weight)[mask].cpu()
        points[step] = dict(score=score_logits(out, y[mask], classes, METRICS[dataset]), weights=stats)
        arrays[step] = out
    _, info = adapt_reweight(model, visible, seed=seed, observer=observer, observe_steps=set(stops), **options)
    return points, arrays, info


def initial_options(dataset, model):
    base = deepcopy(seed_choice(dataset, model)['options'])
    yield 'previous_locked', base
    if dataset not in ('elliptic', 'twitch'): return
    # Predeclared controlled contrasts. Loss formula and multiplicative composition stay fixed.
    trials = [(.7,.1,.001,.1,1.), (.9,.1,.001,.1,1.), (.97,.1,.001,.1,1.),
              (.995,.1,.001,.1,1.), (.9,1.,.003,.1,.01), (.9,1.,.003,.1,1.),
              (.9,1.,.003,.1,100.), (.7,1.,.003,10.,1.),
              (.9,3.,.003,.1,1.), (.97,1.,.01,.1,.01)]
    for i, (p, gain, lr, alpha, beta) in enumerate(trials):
        ratio = p/(1-p)
        yield f'control{i:02}', dict(steps=10, lr=lr, alpha=alpha, beta=beta, prototype_ratio=ratio,
            environment_ratio=ratio, hidden_dim=32, init_probability=p, init_gain=gain)


def tune(dataset, model_name, raw):
    path = ART / dataset / model_name / 'locked.json'
    if path.exists(): return read(path)
    published=ROOT/f'configs/locked/{dataset}_{model_name}.json'
    if published.exists():
        locked=read(published);save(path,locked);return locked
    choice = seed_choice(dataset, model_name)
    if dataset in ('cora', 'amazon_photo'):
        locked = dict(dataset=dataset, model=model_name, **choice, source='validation-locked v3 reused', selection_seeds=[0,1,2], test_used=False)
        save(path, locked); return locked
    graphs = prepare(raw, choice['config']['preprocessing'])['valid']
    row = train(dataset, model_name, choice['config'], 0, raw)
    model, classes, _ = load_checkpoint(row['checkpoint'], 'cpu', dataset, model_name)
    candidates = []
    for label, opts in initial_options(dataset, model_name):
        trial_path = ART / dataset / model_name / 'search' / f'{label}.json'
        if trial_path.exists(): candidates += read(trial_path); continue
        stops = sorted(set((1,3,5,10,opts['steps'])))
        opts = {**opts, 'steps':max(stops)}
        per = [adapt_points(model,g,classes,dataset,opts,i,(0,*stops))[0] for i,g in enumerate(graphs)]
        trials = []
        for stop in stops:
            scores = [p[stop]['score'] for p in per]
            robust = min(statistics.mean(scores[:3]), statistics.mean(scores[3:])) if dataset=='elliptic' else statistics.mean(scores)
            trials.append(dict(label=label, options={**opts,'steps':stop}, score=statistics.mean(scores), robust=robust,
                per_graph=scores, zero=[p[0]['score'] for p in per], weights=[p[stop]['weights'] for p in per]))
        save(trial_path,trials); candidates += trials
        best = max(trials,key=lambda t:(t['robust'],t['score']))
        print(f'SEARCH {dataset}/{model_name}/{label} val={best["score"]:.6f} step={best["options"]["steps"]}',flush=True)
    # One stop per initialization/hyperparameter setting, then best three unique settings.
    by_label = {}
    for c in candidates:
        if c['label'] not in by_label or (c['robust'], c['score'], -c['options']['steps']) > (by_label[c['label']]['robust'],by_label[c['label']]['score'],-by_label[c['label']]['options']['steps']): by_label[c['label']] = c
    shortlist = sorted(by_label.values(), key=lambda c:(-c['robust'],-c['score'],c['options']['steps'],c['label']))[:3]
    # Keep the former locked setting as a fourth comparator if absent.
    old = next(o for label,o in initial_options(dataset,model_name) if label=='previous_locked')
    if not any(c['options']==old for c in shortlist): shortlist.append(dict(label='previous_locked_exact',options=old))
    confirmed = []
    for c in shortlist:
        cp = ART / dataset / model_name / 'confirmation' / f'{identity(c["options"])}.json'
        if cp.exists(): confirmed.append(read(cp)); continue
        values, all_per = [], []
        for seed in (0,1,2):
            row = train(dataset,model_name,choice['config'],seed,raw)
            mdl,cl,_ = load_checkpoint(row['checkpoint'],'cpu',dataset,model_name)
            per = [adapt_points(mdl,g,cl,dataset,c['options'],seed+i,(c['options']['steps'],))[0][c['options']['steps']]['score'] for i,g in enumerate(graphs)]
            values.append(statistics.mean(per)); all_per.append(per)
        mean_per = [statistics.mean(p[i] for p in all_per) for i in range(len(graphs))]
        robust = min(statistics.mean(mean_per[:3]),statistics.mean(mean_per[3:])) if dataset=='elliptic' else statistics.mean(mean_per)
        result = dict(**c, confirmation=values, confirmation_mean=statistics.mean(values), confirmation_robust=robust)
        save(cp,result); confirmed.append(result)
    winner = max(confirmed,key=lambda c:(c['confirmation_robust'],c['confirmation_mean'],-c['options']['steps'],c['label']))
    locked = dict(dataset=dataset,model=model_name,label=choice['label'],config=choice['config'],options=winner['options'],
        selection=winner, selection_seeds=[0,1,2],test_used=False, source='v5 validation-only controlled adapter search')
    save(path,locked)
    print(f'LOCK {dataset}/{model_name} {winner["label"]} {winner["options"]}',flush=True)
    return locked


def evaluate_seed(dataset, model_name, raw, locked, seed, mode='both', category='confirmed'):
    path = ART / dataset / model_name / category / mode / f'seed{seed}' / 'summary.json'
    if path.exists():
        saved=read(path)
        if saved['locked_sha256']!=identity(locked) or saved['seed']!=seed or saved['mode']!=mode:
            raise ValueError('Existing evaluation does not match requested configuration')
        return saved
    row = train(dataset,model_name,locked['config'],seed,raw)
    model,classes,_ = load_checkpoint(row['checkpoint'],'cpu',dataset,model_name)
    frozen = {k:v.clone() for k,v in model.state_dict().items()}
    graphs = prepare(raw,locked['config'].get('preprocessing',{}))['test']
    save(path.parent/'evaluation_plan.json',dict(seed=seed,mode=mode,locked_sha256=identity(locked),checkpoint_sha256=row['checkpoint_sha256'],
         labels_in_adaptation=False,reset_adapter_per_graph=True,test_used_for_selection=False))
    rows = []
    opts = {**locked['options'], 'mode':mode}
    for i,g in enumerate(graphs):
        gp = path.parent / f'graph{i}.json'
        if gp.exists(): rows.append(read(gp));continue
        start=time.perf_counter()
        baseline,y,pred = predict_graph(model,g,classes)
        points, arrays, info = adapt_points(model,g,classes,dataset,opts,seed+i,(0,opts['steps']))
        record = dict(graph=i,domain=getattr(g,'domain',None),time_step=getattr(g,'time_step',None),environment=getattr(g,'environment',None),
            baseline=score_logits(baseline,y,classes,METRICS[dataset]),zero=points[0]['score'],adapted=points[opts['steps']]['score'],
            initial_weights=points[0]['weights'],final_weights=points[opts['steps']]['weights'],diagnostics=info,seconds=time.perf_counter()-start)
        packed = dict(labels=y.numpy(),classes=classes.numpy(),baseline=baseline.numpy(),zero=arrays[0].numpy(),adapted=arrays[opts['steps']].numpy())
        # Exact logits permit rescoring any aggregation later, including pooled AUC.
        np.savez_compressed(path.parent/f'predictions{i}.npz',**packed)
        if dataset=='elliptic':
            record['confusion']={k:confusion_matrix(y,classes[out.argmax(-1)],labels=[0,1]).tolist() for k,out in
                                 (('baseline',baseline),('zero',arrays[0]),('adapted',arrays[opts['steps']]))}
        save(gp,record);rows.append(record)
    unchanged=all(torch.equal(v,frozen[k]) for k,v in model.state_dict().items())
    if not unchanged:raise RuntimeError('Frozen backbone was mutated')
    result=dict(dataset=dataset,model=model_name,seed=seed,mode=mode,category=category,graphs=len(rows),
        baseline=statistics.mean(r['baseline'] for r in rows),zero=statistics.mean(r['zero'] for r in rows),
        adapted=statistics.mean(r['adapted'] for r in rows),locked_sha256=identity(locked),checkpoint_sha256=row['checkpoint_sha256'],
        backbone_unchanged=unchanged,source_reused=False)
    result.update(delta=result['adapted']-result['baseline'],update_delta=result['adapted']-result['zero'])
    if dataset=='elliptic':result['aggregation']={k:aggregations([r['confusion'][k] for r in rows]) for k in ('baseline','zero','adapted')}
    save(path,result)
    print(f'TEST {dataset}/{model_name}/{mode}/s{seed} {result["baseline"]:.6f}->{result["adapted"]:.6f} delta={result["delta"]:+.6f}',flush=True)
    del model;gc.collect();return result


def reuse_final(dataset, model_name, locked, seed):
    path=ART/dataset/model_name/'confirmed/both'/f'seed{seed}/summary.json'
    if path.exists():
        saved=read(path)
        if saved['locked_sha256']!=identity(locked) or saved['seed']!=seed:
            raise ValueError('Existing final result does not match locked configuration')
        return True
    if dataset in ('cora','amazon_photo'):
        old=PROJECT/f'experiments/capacity_v3/artifacts/{dataset}/{model_name}/test/primary/seed{seed}.json'
        if not old.exists():return False
        r=read(old)
        if r['config']['options']!=locked['options'] or canonical_config(r['config']['config'])!=canonical_config(locked['config']):return False
        b,z,a=r['baseline']['mean'],r['zero']['mean'],r['adapted']['mean']
        per=[dict(graph=i,baseline=x,zero=r['zero']['per_graph'][i],adapted=r['adapted']['per_graph'][i]['reweight']) for i,x in enumerate(r['baseline']['per_graph'])]
    else:
        old=PROJECT/f'experiments/elliptic_twitch_v4/artifacts/{dataset}/{model_name}/test/primary/seed{seed}/summary.json'
        if not old.exists():return False
        r=read(old)
        if r['choice']['options']!=locked['options'] or canonical_config(r['choice']['config'])!=canonical_config(locked['config']):return False
        b,z,a=r['baseline'],r['zero'],r['adapted']
        per=[]
        for i in range(r['graphs']):
            g=read(old.parent/f'graph{i}.json')
            per.append(dict(graph=i,domain=g['domain'],time_step=g['time_step'],baseline=g['baseline']['metric'],zero=g['zero']['metric'],adapted=g['adapted']['metric']))
    save(path,dict(dataset=dataset,model=model_name,seed=seed,mode='both',category='confirmed',graphs=len(per),
        baseline=b,zero=z,adapted=a,delta=a-b,update_delta=a-z,locked_sha256=identity(locked),checkpoint_sha256=r['checkpoint_sha256'],
        source_reused=True,source=str(old),source_sha256=digest(old),per_graph=per,backbone_unchanged=True))
    print(f'REUSE TEST {dataset}/{model_name}/s{seed}',flush=True);return True


def reference(dataset,model_name,raw):
    c=deepcopy(yaml.safe_load((ROOT/f'configs/backbones/{dataset}.yaml').read_text(encoding='utf8'))[model_name])
    c['training']['validation_metric']=METRICS[dataset]
    c['training']['class_balance']='none'
    c['preprocessing']=dict(undirected=False)
    rows=[]
    for seed in (0,1,2):
        path=ART/dataset/model_name/'reference'/f'seed{seed}.json'
        if path.exists():rows.append(read(path));continue
        row=train(dataset,model_name,c,seed,raw,'pooled' if dataset=='elliptic' else 'time_mean')
        mdl,classes,_=load_checkpoint(row['checkpoint'],'cpu',dataset,model_name)
        score=evaluate(mdl,raw['test'],classes,dataset)
        result=dict(dataset=dataset,model=model_name,seed=seed,config=c,checkpoint_sha256=row['checkpoint_sha256'],
            test=score,validation_selection='pooled' if dataset=='elliptic' else 'time_mean',
            provenance='GTrans reference settings; exact TT-GREB implementation unavailable',training=row)
        save(path,result);rows.append(result)
    return rows


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['initialize','audit','reference','tune','final','ablate','all'])
    parser.add_argument('--datasets',nargs='+',choices=ALL_DATASETS,default=list(ALL_DATASETS))
    parser.add_argument('--models',nargs='+',choices=MODELS,default=list(MODELS))
    parser.add_argument('--data-root',type=Path,default=WORKSPACE/'data/data')
    parser.add_argument('--seeds',nargs='+',type=int,default=list(range(10)))
    args=parser.parse_args()
    ART.mkdir(parents=True,exist_ok=True)
    if args.stage in ('initialize','all'):
        print(f'PRESERVED {snapshot()} historical files',flush=True)
        if not (ART/'historical_training_registry_v2.json').exists():build_registry()
        for d in ALL_DATASETS:
            for m in MODELS:save(ROOT/f'configs/starting/{d}_{m}.json',seed_choice(d,m))
        save(ART/'plan.json',dict(selection_seeds=[0,1,2],final_seeds=list(range(10)),ablation_seeds=[0,1,2],
             metrics=METRICS,labels_in_adaptation=False,test_selection=False,graph_prompt=False,
             sequential_order=['metric_audit','reference','diagnosis','ablations','final'],search=list(initial_options('twitch','gcn'))))
    if args.stage in ('audit','all'):historical_audit(PROJECT,ROOT/'reports')
    if args.stage in ('initialize','audit'):return
    for dataset in args.datasets:
        raw=load_data(args.data_root,dataset)
        for name in args.models:
            if args.stage in ('reference','all'):
                from reference_aligned import run_reference
                run_reference(dataset,name,raw)
            if args.stage in ('tune','final','ablate','all'):
                locked=tune(dataset,name,raw)
                if args.stage in ('ablate','all'):
                    for mode in ('features','edges'):
                        for seed in (0,1,2):evaluate_seed(dataset,name,raw,locked,seed,mode,'module_ablation')
                if args.stage in ('final','all'):
                    for seed in args.seeds:
                        if not reuse_final(dataset,name,locked,seed):evaluate_seed(dataset,name,raw,locked,seed)


if __name__=='__main__':main()
