"""Check paired identities, saved predictions and completion before packaging."""
import json
from pathlib import Path
import platform
import statistics
import importlib.metadata
import numpy as np
import torch
from sklearn.metrics import f1_score, roc_auc_score, accuracy_score
import run_study as s


def metric(dataset, labels, logits, classes):
    pred=classes[logits.argmax(-1)]
    if dataset in ('cora','amazon_photo'):return accuracy_score(labels,pred)
    if dataset=='elliptic':return f1_score(labels,pred,average='macro',zero_division=0)
    probs=torch.tensor(logits).softmax(-1).numpy()[:,int(np.flatnonzero(classes==1)[0])]
    return roc_auc_score(labels,probs)


def main():
    report=s.ROOT/'reports'
    env=dict(python=platform.python_version(),platform=platform.platform(),device='cpu',threads=torch.get_num_threads(),
             versions={name:importlib.metadata.version(name) for name in ('torch','torch-geometric','numpy','scipy','scikit-learn','PyYAML')})
    (report/'environment.json').write_text(json.dumps(env,indent=2),encoding='utf8')
    problems=[];checked_graphs=0;reused=0;hashes=0;observed=[]
    checkpoint_index={}
    for rowpath in (s.ART/'training').glob('*/**/training.json'):
        row=s.read(rowpath);checkpoint_index.setdefault(row['checkpoint_sha256'],Path(row['checkpoint']))
    for dataset in s.ALL_DATASETS:
      for name in s.MODELS:
        lock=s.read(s.ART/dataset/name/'locked.json')
        expected_graphs={'cora':8,'amazon_photo':8,'elliptic':33,'twitch':5}[dataset]
        full={}
        for mode in ('both','features','edges'):
          category='confirmed' if mode=='both' else 'module_ablation'
          for seed in (range(10) if mode=='both' else range(3)):
            folder=s.ART/dataset/name/category/mode/f'seed{seed}'
            summarypath=folder/'summary.json'
            if not summarypath.exists():problems.append(f'Missing {summarypath.relative_to(s.ROOT)}');continue
            row=s.read(summarypath)
            if row['locked_sha256']!=s.identity(lock):problems.append('Lock mismatch '+str(summarypath))
            if not row['backbone_unchanged']:problems.append('Backbone changed '+str(summarypath))
            if mode=='both':full[seed]=row['checkpoint_sha256']
            elif full.get(seed)!=row['checkpoint_sha256']:problems.append('Ablation checkpoint mismatch '+str(summarypath))
            if row['source_reused']:
                source=Path(row['source'])
                if s.digest(source)!=row['source_sha256']:problems.append('Reused source changed '+str(source))
                graphs=row['per_graph'];reused+=1
            else:
                graphs=[s.read(folder/f'graph{i}.json') for i in range(expected_graphs)]
                for i,g in enumerate(graphs):
                    npz=folder/f'predictions{i}.npz'
                    with np.load(npz) as saved:
                      for key in ('baseline','zero','adapted'):
                        score=metric(dataset,saved['labels'],saved[key],saved['classes'])
                        # Historical accuracy used torch float32 mean; allow its rounding only.
                        tolerance=8e-8 if dataset in ('cora','amazon_photo') else 1e-10
                        if abs(score-g[key])>tolerance:problems.append(f'Prediction rescore mismatch: {npz}/{key}')
                    checked_graphs+=1
            if len(graphs)!=expected_graphs:problems.append('Wrong graph count '+str(summarypath))
            for key in ('baseline','zero','adapted'):
                if abs(statistics.mean(g[key] for g in graphs)-row[key])>1e-12:problems.append('Graph mean mismatch '+str(summarypath))
            cp=checkpoint_index.get(row['checkpoint_sha256'])
            if cp is None:
                # Older complete results store metadata in their preserved study directory.
                for p in (s.PROJECT/'experiments').glob('*/artifacts/**/training.json'):
                    old=s.read(p)
                    if old.get('checkpoint_sha256')==row['checkpoint_sha256']:
                        cp=Path(old['checkpoint']);checkpoint_index[row['checkpoint_sha256']]=cp;break
            if cp is None:problems.append('Checkpoint cannot be resolved '+str(summarypath))
            elif s.digest(cp)!=row['checkpoint_sha256']:problems.append('Checkpoint hash mismatch '+str(cp))
            else:hashes+=1
            observed.append(dict(dataset=dataset,model=name,mode=mode,seed=seed,graphs=len(graphs),checkpoint_sha256=row['checkpoint_sha256']))
    reference_checked=0
    for dataset in s.ALL_DATASETS:
      for name in s.MODELS:
        for seed in range(3):
            folder=s.ART/dataset/name/'reference_aligned'/f'seed{seed}'
            summary=folder/'summary.json'
            if not summary.exists():problems.append('Missing reference '+str(summary));continue
            row=s.read(summary)
            if s.digest(row['checkpoint'])!=row['checkpoint_sha256']:problems.append('Reference checkpoint changed '+str(summary))
            values=[]
            for i,expected in enumerate(row['test']['per_graph']):
                with np.load(folder/f'predictions{i}.npz') as saved:
                    value=metric(dataset,saved['labels'],saved['logits'],saved['classes']);values.append(value)
                    tolerance=8e-8 if dataset in ('cora','amazon_photo') else 1e-10
                    if abs(value-expected)>tolerance:problems.append('Reference prediction mismatch '+str(summary))
            if abs(statistics.mean(row['test']['per_graph'])-row['test']['mean'])>1e-12:problems.append('Reference mean mismatch '+str(summary))
            reference_checked+=1
    preserved=s.snapshot()
    result=dict(passed=not problems,problems=problems,verified_saved_prediction_graphs=checked_graphs,
        reused_seed_records_verified=reused,checkpoint_hash_checks=hashes,paired_records=len(observed),
        reference_seed_records_verified=reference_checked,historical_files_preserved=preserved,observed=observed)
    (report/'final_audit.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    source_files=[p for folder in ('src','tests','configs') for p in (s.ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    source_files+=list(s.ROOT.glob('*.py'))+[s.ROOT/'requirements.txt',s.ROOT/'README.md',s.ROOT/'RESULTS.md',s.ROOT/'.gitignore']
    (report/'source_manifest.json').write_text(json.dumps({str(p.relative_to(s.ROOT)):s.digest(p) for p in sorted(source_files)},indent=2),encoding='utf8')
    print(json.dumps({k:v for k,v in result.items() if k!='observed'},indent=2))
    if problems:raise SystemExit(1)


if __name__=='__main__':main()
